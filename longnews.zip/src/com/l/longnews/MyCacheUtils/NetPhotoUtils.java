package com.l.longnews.MyCacheUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;

import cn.sharesdk.wechat.utils.l;

import com.lidroid.xutils.BitmapUtils;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v4.util.LruCache;
import android.widget.ImageView;

public class NetPhotoUtils {

	private LruCache<String, Bitmap> lruCache;
	private Bitmap bitmap;

	public NetPhotoUtils() {
		long maxMemory = Runtime.getRuntime().maxMemory() / 8;

		lruCache = new LruCache<String, Bitmap>((int) maxMemory);
	}

	public void display(String PhotoUrl, ImageView imageView) {

		bitmap = getMemoryPhoto(PhotoUrl);

		if (bitmap != null) {

			imageView.setImageBitmap(bitmap);
			System.out.println("从内存获取图片");
			return;
		}

		bitmap = getLocalPhoto(PhotoUrl);

		if (bitmap != null) {

			imageView.setImageBitmap(bitmap);
			
			System.out.println("从===============本地=========获取图片");
			
			return;

		}

		getPhotoFromNet(PhotoUrl, imageView);

	}

	// ================从网络获取图片=====================================
	private void getPhotoFromNet(String url, ImageView iv) {

		NetPhotoTask netPhotoTask = new NetPhotoTask();

		netPhotoTask.execute(iv, url);
	}

	// ===================================================================

	// ====================内存卡中获取和缓存图片================
	private Bitmap getLocalPhoto(String url) {

		try {
			String fileName = MD5Encoder.encode(url);
			String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/zhxw";

			File file = new File(path, fileName);

			FileInputStream in = new FileInputStream(file);

			Bitmap stream = BitmapFactory.decodeStream(in);

			setMemoryPhoto(url, stream);
			return stream;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	private void setLocalPhoto(String url, Bitmap bitmap) {
		try {
			
			String fileName = MD5Encoder.encode(url);
			
			String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/zhxw";
			
			
			System.out.println(url);
			
			File file = new File(path, fileName);

			File parentFile = file.getParentFile();
			
			if (!parentFile.exists()) {
				parentFile.mkdirs();
			}

			bitmap.compress(CompressFormat.JPEG, 100,
					new FileOutputStream(file));
			
		} catch (Exception e) {
			System.out.println("文件没有找到");
			e.printStackTrace();
		}
	}

	// ==============================================================

	// ====================运行内存中获取和保存图片===============================
	private Bitmap getMemoryPhoto(String url) {

		return lruCache.get(url);

	}

	private void setMemoryPhoto(String url, Bitmap bitmap) {

		lruCache.put(url, bitmap);
	}

	// ===================================================================

	// 网络图片人物类@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	class NetPhotoTask extends AsyncTask<Object, String, Bitmap> {

		private HttpURLConnection conn;
		private ImageView iv;
		private String url;

		@Override
		protected Bitmap doInBackground(Object... params) {

			iv = (ImageView) params[0];
			url = (String) params[1];

			iv.setTag(url);

			Bitmap bitmap = downloadPhoto(url);

			return bitmap;
		}

		@Override
		protected void onProgressUpdate(String... values) {

			System.out.println(values[0]);
		}

		// 网络下载图片结束后
		@Override
		protected void onPostExecute(Bitmap result) {

			if (result != null) {

				String bUrl = (String) iv.getTag();
				System.out.println("网络设置图片");
				if (url.equals(bUrl)) {

					iv.setImageBitmap(result);
					// 设置本地缓存
					setLocalPhoto(bUrl, result);
					// 设置内存缓存
					// setMemoryPhoto(bUrl, result);

				}

			}

		}

		private Bitmap downloadPhoto(String url) {

			try {
				conn = (HttpURLConnection) new URL(url).openConnection();

				conn.setConnectTimeout(5000);
				conn.setRequestMethod("GET");
				int code = conn.getResponseCode();

				if (code == 200) {

					InputStream in = conn.getInputStream();

					Bitmap bitmap = BitmapFactory.decodeStream(in);

					return bitmap;

				}

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.disconnect();
			}

			return null;

		}

	}
	// 网络图片人物类@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

}

class MD5Encoder {

	public static String encode(String string) throws Exception {
		byte[] hash = MessageDigest.getInstance("MD5").digest(
				string.getBytes("UTF-8"));
		StringBuilder hex = new StringBuilder(hash.length * 2);
		for (byte b : hash) {
			if ((b & 0xFF) < 0x10) {
				hex.append("0");
			}
			hex.append(Integer.toHexString(b & 0xFF));
		}
		return hex.toString();
	}
}

