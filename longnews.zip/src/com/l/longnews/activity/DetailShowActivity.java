package com.l.longnews.activity;

import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.onekeyshare.OnekeyShare;

import com.l.longnews.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.TextSize;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

public class DetailShowActivity extends Activity {

	private ImageView back;
	private ImageView size;
	private ImageView share;
	private WebView web;
	protected int mSelectSize;
	private WebSettings webSettings;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.item_detail_show);

		initView();
		initData();
	}

	private void initView() {
	
		back = (ImageView) findViewById(R.id.back_news_lv);
		size = (ImageView) findViewById(R.id.T_size);
		share = (ImageView) findViewById(R.id.share);
		web = (WebView) findViewById(R.id.web);
	}

	private void initData() {

		webSettings = web.getSettings();
		back.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

				finish();

			}
		});

		size.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				setTextSize();
			}

		});
		
		share.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				showShare();
			}
		});

		String url = getIntent().getStringExtra("url");

		web.setWebViewClient(new WebViewClient() {

			
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// TODO Auto-generated method stub
				web.loadUrl(url);
				return true;
				//return super.shouldOverrideUrlLoading(view, url);
			}
		});
		web.setWebChromeClient(new WebChromeClient() {

			@Override
			public void onReceivedTouchIconUrl(WebView view, String url,
					boolean precomposed) {
				// TODO Auto-generated method stub
				// super.onReceivedTouchIconUrl(view, url, precomposed);

				web.loadUrl(url);
			}

		});
		
		 webSettings.setJavaScriptEnabled(true);  
		 webSettings.setDomStorageEnabled(true);
		 webSettings.setLoadWithOverviewMode(true);
		 webSettings.setAllowFileAccess(true);
		 webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
		 webSettings.setSupportZoom(true);
		 
		 
         web.loadUrl("http://zntx.cc/"); 
	}

	private void setTextSize() {
		Builder builder = new AlertDialog.Builder(this);
		String[] sizeS = new String[] { "超大号字体", "大号字体", "正常字体", "小号字体",
				"超小号字体" };

		builder.setTitle("请选择字体的大小");

		builder.setSingleChoiceItems(sizeS, mSelectSize,
				new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int which) {

						mSelectSize = which;
						switch (which) {
						case 0:
							webSettings.setTextSize(TextSize.LARGEST);
							break;
						case 1:
							webSettings.setTextSize(TextSize.LARGER);
							break;
						case 2:
							webSettings.setTextSize(TextSize.NORMAL);
							break;
						case 3:
							webSettings.setTextSize(TextSize.SMALLER);
							break;
						case 4:
							webSettings.setTextSize(TextSize.SMALLEST);
							break;

						}

						dialog.dismiss();
					}

				});
		builder.show();

	}
	
	
	private void showShare() {
		 OnekeyShare oks = new OnekeyShare();
		 //关闭sso授权
		 oks.disableSSOWhenAuthorize(); 
		 // title标题，印象笔记、邮箱、信息、微信、人人网、QQ和QQ空间使用
		 oks.setTitle("标题");
		 // titleUrl是标题的网络链接，仅在Linked-in,QQ和QQ空间使用
		 oks.setTitleUrl("http://sharesdk.cn");
		 // text是分享文本，所有平台都需要这个字段
		 oks.setText("我是分享文本");
		 //分享网络图片，新浪微博分享网络图片需要通过审核后申请高级写入接口，否则请注释掉测试新浪微博
		 oks.setImageUrl("http://f1.sharesdk.cn/imgs/2014/02/26/owWpLZo_638x960.jpg");
		 // imagePath是图片的本地路径，Linked-In以外的平台都支持此参数
		 //oks.setImagePath("/sdcard/test.jpg");//确保SDcard下面存在此张图片
		 // url仅在微信（包括好友和朋友圈）中使用
		 oks.setUrl("http://sharesdk.cn");
		 // comment是我对这条分享的评论，仅在人人网和QQ空间使用
		 oks.setComment("我是测试评论文本");
		 // site是分享此内容的网站名称，仅在QQ空间使用
		 oks.setSite("ShareSDK");
		 // siteUrl是分享此内容的网站地址，仅在QQ空间使用
		 oks.setSiteUrl("http://sharesdk.cn");

		// 启动分享GUI
		 oks.show(this);
		 }

}
