package com.l.longnews.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;

import com.l.longnews.R;
import com.l.longnews.utils.PrefUtil;

public class GuideActivity extends Activity {

	private ViewPager vp;
	private LinearLayout point_group;
	private Button bt;
	// 设置点id的数组
	int[] page_ids = new int[] { R.drawable.guide_1, R.drawable.guide_2,
			R.drawable.guide_3 };
	private ArrayList<ImageView> guide_pages;
	private RelativeLayout rl2;
	private ImageView point_red;
	private int point_with;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_guide);

		initViews();
		
		
	}

	private void initViews() {

		vp = (ViewPager) findViewById(R.id.guide_vp);

		point_group = (LinearLayout) findViewById(R.id.guide_ll);

		bt = (Button) findViewById(R.id.guide_bt);

		rl2 = (RelativeLayout) findViewById(R.id.guide_rl2);

		point_red = (ImageView) findViewById(R.id.point_red);

		guide_pages = new ArrayList<ImageView>();

		// 创建背景图片对应的View
		for (int i = 0; i < page_ids.length; i++) {

			ImageView guide_page = new ImageView(GuideActivity.this);

			guide_page.setBackgroundResource(page_ids[i]);

			guide_pages.add(guide_page);

		}

		bt.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				
				PrefUtil.setBooleanSpValue(GuideActivity.this, "is_show_guide",false);
				
				startActivity(new Intent(GuideActivity.this, MainActivity.class));
				finish();
			}
		});

		addPoint();

		point_group.getViewTreeObserver().addOnGlobalLayoutListener(
				new OnGlobalLayoutListener() {

					public void onGlobalLayout() {
						View point1 = point_group.getChildAt(0);
						View point2 = point_group.getChildAt(1);

						point_with = point2.getLeft() - point1.getLeft();

					}
				});

		GuideAdapter guideAdapter = new GuideAdapter();

		vp.setAdapter(guideAdapter);

		vp.setOnPageChangeListener(new OnPageChangeListener() {

			public void onPageSelected(int position) {
				if (position == 2) {
					bt.setVisibility(View.VISIBLE);
				} else {
					bt.setVisibility(View.INVISIBLE);
				}
			}

			public void onPageScrolled(int position, float positionOffset,
					int positionOffsetPixels) {

				android.widget.RelativeLayout.LayoutParams point_Params = new RelativeLayout.LayoutParams(
						10, 10);
				
				point_Params.leftMargin = (int) (positionOffset * point_with+position*point_with);

				point_red.setLayoutParams(point_Params);

			}

			public void onPageScrollStateChanged(int state) {

			}
		});

	}

	// 向程序底部添加三个点
	private void addPoint() {

		for (int i = 0; i < page_ids.length; i++) {

			View view = new View(this);
			LayoutParams layoutParams = new LinearLayout.LayoutParams(10, 10);
			view.setBackgroundResource(R.drawable.shape_point_grey);
			if (i > 0) {
				layoutParams.leftMargin = 10;
			}
			view.setLayoutParams(layoutParams);

			point_group.addView(view);

		}

	}

	// GUIDE的页面适配器
	private class GuideAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return page_ids.length;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {

			return arg0 == arg1;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {

			container.addView(guide_pages.get(position));
			return guide_pages.get(position);
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {

			container.removeView((View) object);

		}

	}

}
