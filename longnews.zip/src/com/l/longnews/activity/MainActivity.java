package com.l.longnews.activity;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;
import com.l.longnews.R;
import com.l.longnews.fragments.MainFragment;
import com.l.longnews.fragments.MenuFragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.Window;

public class MainActivity extends SlidingFragmentActivity {

	String SLIDE_MENU = "slide_menu";
	String SLIDE_MAIN = "slide_main";
	private FragmentManager fragmentManager;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		setBehindContentView(R.layout.slide_menu);

		SlidingMenu slidingMenu = getSlidingMenu();
		slidingMenu.setTouchModeAbove(slidingMenu.TOUCHMODE_FULLSCREEN);
		slidingMenu.setBehindOffset(200);
		slidingMenu.setSlidingEnabled(true);

		initFragment();
	}

	private void initFragment() {

		fragmentManager = getSupportFragmentManager();

		FragmentTransaction transaction = fragmentManager.beginTransaction();

		transaction.replace(R.id.menu_page, new MenuFragment(), SLIDE_MENU);
		transaction.replace(R.id.main_page, new MainFragment(), SLIDE_MAIN);

		transaction.commit();

	}

	public MenuFragment getMenuFragment() {

		MenuFragment menu = (MenuFragment) fragmentManager
				.findFragmentByTag(SLIDE_MENU);
		return menu;

	}

	public MainFragment getMainFragment() {

		MainFragment main = (MainFragment) fragmentManager
				.findFragmentByTag(SLIDE_MAIN);
		return main;

	}
}
