package com.l.longnews.activity;

import cn.sharesdk.framework.ShareSDK;

import com.l.longnews.R;
import com.l.longnews.R.layout;
import com.l.longnews.R.menu;
import com.l.longnews.utils.PrefUtil;
import com.mob.MobSDK;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

public class SplashActivity extends Activity {

	private RelativeLayout splash;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);

		initView();
		initAnimation();
		MobSDK.init(this,"25e242e3055f4","3113735085f142a94e87225994edd10f");
	}

	/**
	 * 初始化View的方法
	 */
	private void initView() {

		splash = (RelativeLayout) findViewById(R.id.splash);
		//初始化
		
	}

	/**
	 * 初始化动画的方法
	 */
	private void initAnimation() {

		// 动画集合
		AnimationSet animationSet = new AnimationSet(false);
		// 旋转动画
		RotateAnimation rotateAnimation = new RotateAnimation(0, 360,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		rotateAnimation.setDuration(1000);
		rotateAnimation.setFillAfter(true);
		// 缩放动画
		ScaleAnimation scaleAnimation = new ScaleAnimation(0, 1, 0, 1,
				ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
				ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
		scaleAnimation.setDuration(1000);
		scaleAnimation.setFillAfter(true);
		// 渐变动画
		AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);
		alphaAnimation.setDuration(1000);
		alphaAnimation.setFillAfter(true);
		// 添加动画集合
		animationSet.addAnimation(rotateAnimation);
		animationSet.addAnimation(scaleAnimation);
		animationSet.addAnimation(alphaAnimation);
		// 设置动画监听
		animationSet.setAnimationListener(new AnimationListener() {

			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			public void onAnimationEnd(Animation animation) {
				boolean is_show_guide = PrefUtil.getBooleanSpValue(
						SplashActivity.this, "is_show_guide", true);
				
				if (is_show_guide) {
					startActivity(new Intent(SplashActivity.this,
							GuideActivity.class));
				
				} else {
					startActivity(new Intent(SplashActivity.this,
							MainActivity.class));
				}
				
				finish();

			}
		});

		// 开启动画
		splash.startAnimation(animationSet);

	}

}
