package com.l.longnews.bean;

import java.util.ArrayList;

public class NewsData {

	public ArrayList<typeData> data;

	public String retcode;

	public class typeData {

		public String id;
		public String title;
		public int type;
		public ArrayList<children> children;

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "数据门类： [" + title + "]"+children;
		}

	}

	public class children {

		public String id;
		public String title;
		public int type;
		public String url;
		public String url1;

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "新闻的类别： [" + title + " ]";
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NewsData:----" + data + "-----";
	}

}
