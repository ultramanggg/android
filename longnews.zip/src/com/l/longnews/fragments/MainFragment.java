package com.l.longnews.fragments;

import java.util.ArrayList;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.l.longnews.R;
import com.l.longnews.activity.MainActivity;
import com.l.longnews.mainpage.BasePage;
import com.l.longnews.mainpage.NewsTypeBasePage;
import com.l.longnews.mainpage.impl.GovPage;
import com.l.longnews.mainpage.impl.HomePage;
import com.l.longnews.mainpage.impl.NewsPage;
import com.l.longnews.mainpage.impl.SettingPage;
import com.l.longnews.mainpage.impl.SmartPage;
import com.l.longnews.mainpage.newsTypeImpl.PhotoPageType;
import com.l.longnews.view.MyViewPager;

public class MainFragment extends BaseFragment {

	private View main;
	private MyViewPager vp;
	private ImageView titleImg;
	private TextView title_text;

	ArrayList<BasePage> pages = new ArrayList<BasePage>();

	private RadioGroup rg;
	private SlidingMenu slidingMenu;
	private ImageView pic;

	@Override
	protected View initView() {

		MainActivity m = (MainActivity) mActivity;
		slidingMenu = m.getSlidingMenu();

		main = View.inflate(mActivity, R.layout.fragment_main, null);

		vp = (MyViewPager) main.findViewById(R.id.fmain_vp);

		titleImg = (ImageView) main.findViewById(R.id.title_img);
		title_text = (TextView) main.findViewById(R.id.title_text);
		pic = (ImageView) main.findViewById(R.id.icon_pic);
		rg = (RadioGroup) main.findViewById(R.id.main_rg);
		pic.setEnabled(false);
		// ViewUtils.inject(this, main);

		return main;
	}

	@Override
	protected void initData() {

		
		pic.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				changePhotoPageIcon();
			}
		});
		
		pages.add(new HomePage(mActivity));
		pages.add(new NewsPage(mActivity));
		pages.add(new SmartPage(mActivity));
		pages.add(new GovPage(mActivity));
		pages.add(new SettingPage(mActivity));

		mainPagerAdpter adpter = new mainPagerAdpter();

		vp.setAdapter(adpter);

		vp.setOnPageChangeListener(new myOnPageChangeListener());

		rg.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			public void onCheckedChanged(RadioGroup group, int checkedId) {

				switch (checkedId) {
				case R.id.main_bt_home:

					vp.setCurrentItem(0, false);// 去掉切换页面的动画
					setMainTitle("主页", false);
					break;
				case R.id.main_bt_news:
					vp.setCurrentItem(1, false);// 去掉切换页面的动画
					setMainTitle("新闻", true);
					break;
				case R.id.main_bt_smart:

					vp.setCurrentItem(2, false);// 去掉切换页面的动画
					setMainTitle("智汇中心", true);
					break;
				case R.id.main_bt_gov:

					vp.setCurrentItem(3, false);// 去掉切换页面的动画
					setMainTitle("政务", true);
					break;
				case R.id.main_bt_setting:

					vp.setCurrentItem(4, false);// 去掉切换页面的动画
					setMainTitle("设置", false);
					break;

				}

			}
		});
		
		rg.check(R.id.main_bt_home);
		pages.get(0).initData();
		
		titleImg.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				 
				    slidingMenu.showMenu();	
				
			}
		});
		
//		//禁止Viewpage滑动；
//		vp.setOnTouchListener(new OnTouchListener() {
//
//			public boolean onTouch(View v, MotionEvent event) {
//
//				return true;
//			}
//		});

	}

	class mainPagerAdpter extends PagerAdapter {

		@Override
		public int getCount() {
			return pages.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {

			BasePage currentpage = pages.get(position);
			container.addView(currentpage.pageView);
			

			return currentpage.pageView;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {

			container.removeView((View) object);
		}

	}
	
	//当vp的页面改变时调用更新数据的方法；
	
	class myOnPageChangeListener implements OnPageChangeListener {

		public void onPageScrollStateChanged(int arg0) {
			
			
		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		public void onPageSelected(int arg0) {
			pages.get(arg0).initData();
			
			setPageIconState(false);
		}

	}

	public void setMainTitle(String text, boolean menuIsOpen) {

		title_text.setText(text);
		if (menuIsOpen) {
			
			titleImg.setEnabled(true);
			titleImg.setVisibility(View.VISIBLE);
			slidingMenu.setBehindOffset(200);

		} else {
			titleImg.setVisibility(View.INVISIBLE);
			titleImg.setEnabled(false);
			slidingMenu.setBehindWidth(0);

		}

	}

	/**
	 * 传入入一个新闻页面类别对象
	 * 并将新闻页面framelayout的数据清空替换为传入页面的view对象
	 * @param page  新闻类别界面的对象，或者其子类的对象
	 */
	public void setNewsPage(NewsTypeBasePage page){
		
		if(page instanceof PhotoPageType){
			addPhoneM(page);
		}
		NewsPage newsPage = (NewsPage) pages.get(1);
		FrameLayout page_fl = newsPage.page_fl;
		
		
		page_fl.removeAllViews();
		
		
		page_fl.addView(page.pageView);
		
	}
	
	/**
	 *   对标题栏文字进行修改
	 * @param Title
	 */
	public void setTitleBarText(String Title){
		title_text.setText(Title);
	}
	
	
	int [] picID=new int[]{R.drawable.icon_pic_list_type,R.drawable.icon_pic_grid_type};
	boolean islv=true;
	
	public void changePhotoPageIcon(){
		
		if(islv){
			
			pic.setImageResource(picID[1]);
			
			photo.changeLayout(islv);
			
		}else{
			pic.setImageResource(picID[0]);	
			photo.changeLayout(islv);
			
		}
		
		islv=!islv;
		
	}
	
	public void setPageIconState(boolean b){
		
		if(b){
			pic.setVisibility(View.VISIBLE);
			pic.setEnabled(true);
			
		}else{
			pic.setVisibility(View.INVISIBLE);
			pic.setEnabled(false);
		}
		
		
	}
	
	/**
	 * @return  true 是list 否则是 gride
	 */
	public boolean getPageIconState(){
		
		return islv;
		
	}
	
	NewsTypeBasePage photo;
	
	public void addPhoneM(NewsTypeBasePage newsTypeBasePage) {
		
		photo =newsTypeBasePage;
	}
}
