package com.l.longnews.fragments;

import java.util.ArrayList;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.l.longnews.R;
import com.l.longnews.activity.MainActivity;
import com.l.longnews.bean.NewsData;
import com.l.longnews.bean.NewsData.typeData;
import com.l.longnews.mainpage.NewsTypeBasePage;
import com.l.longnews.mainpage.newsTypeImpl.InteractPageType;
import com.l.longnews.mainpage.newsTypeImpl.NewsPageType;
import com.l.longnews.mainpage.newsTypeImpl.PhotoPageType;
import com.l.longnews.mainpage.newsTypeImpl.TopicPageType;

public class MenuFragment extends BaseFragment {

	private ListView lv;
	private ArrayList<typeData> types;
	private MenuAdapter menuAdapter;
	
	private int currentType=0;
	private ArrayList<NewsTypeBasePage> newsTypes;

	@Override
	protected View initView() {
		View view = View.inflate(mActivity, R.layout.fragment_menu, null);

		lv = (ListView) view.findViewById(R.id.menu_listView);

		return view;
		
	}

	@Override
	protected void initData() {

		lv.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				
					
				currentType=position;
				
				menuAdapter.notifyDataSetChanged();
				
				//根据当前的数据类型更新新闻页面
				setNewsPageDataByType(currentType);
				
				//更新标题数据
				
				//收起菜单
				MainActivity m = (MainActivity) mActivity;
				SlidingMenu slidingMenu = m.getSlidingMenu();
				slidingMenu.toggle();
			
			}
		});
	}

	/**
	 * 设置新闻Tab对应slidingmenu的数据
	 * @param data  新闻数据对象newsData
	 */
	public void setNewsMenuData(NewsData data){
		
		types = data.data;
		
		newsTypes = new ArrayList<NewsTypeBasePage>();
		
		//新闻页面数据
		
	
		newsTypes.add(new NewsPageType(mActivity,types.get(0)));
		newsTypes.add(new TopicPageType(mActivity,types.get(1)));
		newsTypes.add(new PhotoPageType(mActivity,types.get(2)));
		newsTypes.add(new InteractPageType(mActivity,types.get(3)));
		
		menuAdapter = new MenuAdapter();
		
		lv.setAdapter(menuAdapter);
		
	}
	
	class MenuAdapter extends BaseAdapter{

		public int getCount() {
			// TODO Auto-generated method stub
			return types.size();
		}

		public typeData getItem(int position) {
			// TODO Auto-generated method stub
			return types.get(position);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			
			View item= View.inflate(mActivity, R.layout.menu_lv_item,null);
			TextView  tv  = (TextView) item.findViewById(R.id.menu_item_tv);
			tv.setText(types.get(position).title);
			if(currentType==position){
				tv.setEnabled(true);
			}else{
				tv.setEnabled(false);
			}
		
			return item;
		}
		
	}
	
	public void setNewsPageDataByType(int type) {
		
		MainActivity m = (MainActivity) mActivity;
		MainFragment mainFragment = m.getMainFragment();
		
		//更新类别页面的数据
		newsTypes.get(type).initData();
		
		if(type==2){
			mainFragment.setPageIconState(true);
		}else{
			mainFragment.setPageIconState(false);
		}
		//使用主页面对应的Fragment对象的更新数据方法，更新页面的数据；
		mainFragment.setNewsPage(newsTypes.get(type));
		
		if(mainFragment.photo!=null){
			mainFragment.changePhotoPageIcon();
		}
	}
	
	
}
