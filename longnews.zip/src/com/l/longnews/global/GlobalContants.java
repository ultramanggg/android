package com.l.longnews.global;

public class GlobalContants {

	public static final String SERVICE_URL = "http://10.0.2.2:8080/zhbj";
	public static final String CATEGORIES_URL =SERVICE_URL+ "/categories.json";
	public static final String PHOTOS_URL = SERVICE_URL
			+ "/photos/photos_1.json";//图片地址
}
