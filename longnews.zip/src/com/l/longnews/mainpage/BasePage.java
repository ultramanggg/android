package com.l.longnews.mainpage;

import com.l.longnews.R;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;

public  class BasePage {

	public Activity mActivity;
	public View pageView;
	public FrameLayout page_fl;
	
	
	public BasePage(Activity activity) {
		this.mActivity = activity;
		pageView=initView();
		page_fl = (FrameLayout) pageView.findViewById(R.id.page_fl);
	}

	public View initView(){
		
		return View.inflate(mActivity,R.layout.page_base,null);
	};
	
	public void initData(){
		System.out.println("页面的数据可以初始化");
	}

	
}
