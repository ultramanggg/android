package com.l.longnews.mainpage;

import com.l.longnews.R;
import com.l.longnews.activity.MainActivity;
import com.l.longnews.bean.NewsData.typeData;
import com.l.longnews.fragments.MainFragment;

import android.app.Activity;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;

public class NewsTypeBasePage {
	
	public Activity mActivity;
	public View pageView;
	public typeData tpData;
	public FrameLayout page_fl;
	
	public NewsTypeBasePage(Activity activity,typeData tpData) {
		this.mActivity = activity;
		this.tpData=tpData;
		pageView=initView();
		page_fl= (FrameLayout) pageView.findViewById(R.id.news_type_fl);
	}

	
	public View initView(){
		
		return View.inflate(mActivity,R.layout.news_type_page,null);
	};
	
	public void initData(){
		System.out.println("页面的数据可以初始化");
	}
	
	public void updateMainTitle(String title){
		MainActivity m = (MainActivity) mActivity;
		MainFragment mainFragment = m.getMainFragment();
		mainFragment.setTitleBarText(title);
	}


	public void changeLayout(boolean islv) {
		// TODO Auto-generated method stub
		
	}
}
