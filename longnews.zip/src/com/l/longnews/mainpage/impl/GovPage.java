package com.l.longnews.mainpage.impl;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.l.longnews.R;
import com.l.longnews.activity.MainActivity;
import com.l.longnews.mainpage.BasePage;

public class GovPage extends BasePage {

	public GovPage(Activity activity) {
		super(activity);
	}

	
	
	@Override
	public void initData() {
		
		TextView tv = (TextView) page_fl.getChildAt(0);
		tv.setText("政务");
	}
	
	
	
}
