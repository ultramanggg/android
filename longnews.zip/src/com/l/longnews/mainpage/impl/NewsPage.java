package com.l.longnews.mainpage.impl;

import android.app.Activity;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;
import com.l.longnews.R;
import com.l.longnews.activity.MainActivity;
import com.l.longnews.bean.NewsData;
import com.l.longnews.fragments.MainFragment;
import com.l.longnews.fragments.MenuFragment;
import com.l.longnews.global.GlobalContants;
import com.l.longnews.mainpage.BasePage;
import com.l.longnews.mainpage.NewsTypeBasePage;
import com.l.longnews.mainpage.newsTypeImpl.NewsPageType;
import com.l.longnews.utils.NetCacheUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

public class NewsPage extends BasePage {

	public NewsPage(Activity activity) {
		super(activity);
	}

	
	@Override
	public void initData() {
		
//		TextView tv = (TextView) page_fl.getChildAt(0);
//		tv.setText("新闻");
		
		if(!TextUtils.isEmpty(NetCacheUtils.getCache(mActivity, GlobalContants.CATEGORIES_URL))){
			
			
			parseData(NetCacheUtils.getCache(mActivity, GlobalContants.CATEGORIES_URL));
			
			
		}
		
		getNewsPageDataFromService();
	
	}

	private void getNewsPageDataFromService() {
		HttpUtils httpUtils = new HttpUtils();
		httpUtils.send(HttpMethod.GET, GlobalContants.CATEGORIES_URL,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						String result = responseInfo.result;

						// System.out.println("成功："+result);
						
						NetCacheUtils.addCache(mActivity,GlobalContants.CATEGORIES_URL,result);	
						
						
						parseData(result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						System.out.println("错误：" + msg);
						error.printStackTrace();
						
						
					}
				});

	}

	public void parseData(String data) {

		Gson gson = new Gson();

		NewsData newsData = gson.fromJson(data, NewsData.class);
		
		//System.out.println(data);
		
		
		
		
		

		// System.out.println(newsData.toString());
		MainActivity m = (MainActivity) mActivity;

		MenuFragment menuFragment = m.getMenuFragment();
		

		

		menuFragment.setNewsMenuData(newsData);
		
		
	   //设置新闻选项对应的默认页面
		MainFragment mainFragment = m.getMainFragment();
		
		NewsPageType newspage = new NewsPageType(mActivity,newsData.data.get(0));
		newspage.initData();
		mainFragment.setNewsPage(newspage);
		
	}

	
}
