package com.l.longnews.mainpage.impl;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

import com.l.longnews.R;
import com.l.longnews.mainpage.BasePage;

public class SettingPage extends BasePage {

	public SettingPage(Activity activity) {
		super(activity);
	}

	@Override
	public void initData() {
		TextView tv = (TextView) page_fl.getChildAt(0);
		tv.setText("设置");
	}
}
