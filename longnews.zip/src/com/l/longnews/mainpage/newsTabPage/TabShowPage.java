package com.l.longnews.mainpage.newsTabPage;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.l.longnews.R;
import com.l.longnews.activity.DetailShowActivity;
import com.l.longnews.bean.TabNewsData;
import com.l.longnews.bean.NewsData.children;
import com.l.longnews.bean.TabNewsData.TabDetail;
import com.l.longnews.bean.TabNewsData.TabLvData;
import com.l.longnews.bean.TabNewsData.TabVpData;
import com.l.longnews.global.GlobalContants;
import com.l.longnews.mainpage.BasePage;
import com.l.longnews.utils.NetCacheUtils;
import com.l.longnews.view.ListView.MyReListView;
import com.l.longnews.view.ListView.MyReListView.OnRefreshListener;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.viewpagerindicator.CirclePageIndicator;

public class TabShowPage extends BasePage {

	private TextView tvText;
	children tabData;
	private ViewPager vp;
	private View tab_show;
	private MyReListView lv;
	int CurrentTuId=0;
	Handler mHander = new Handler(){
		
		public void handleMessage(android.os.Message msg) {
			
			switch (msg.what) {
			case 0:
				
				if(CurrentTuId<vpList.size()){
					CurrentTuId=vp.getCurrentItem()+1;
				}else{
					CurrentTuId=0;
				}
				
				vp.setCurrentItem(CurrentTuId);
				
				mHander.sendEmptyMessageDelayed(0, 3000);
				
				break;

			default:
				break;
			}
			
			
		};
	};
	
	public TabShowPage(Activity activity, children children) {
		super(activity);
		// TODO Auto-generated constructor stub
		tabData = children;
	}

	/*
	 * 这里设计新闻页面的某一个选项对应的页面是什么
	 */
	@Override
	public View initView() {

		tab_show = View.inflate(mActivity, R.layout.tab_news, null);

		View HeaderVp = View.inflate(mActivity, R.layout.tab_news_lv_header,
				null);

		vp = (ViewPager) HeaderVp.findViewById(R.id.tab_news_vp);
		header_title = (TextView) HeaderVp
				.findViewById(R.id.tab_news_header_title);

		zhishi = (CirclePageIndicator) HeaderVp
				.findViewById(R.id.tab_news_indicator);

		// View headRe=View.inflate(mActivity,
		// R.layout.tab_news_lv_heander_refresh,null);

		lv = (MyReListView) tab_show.findViewById(R.id.tab_news_lv);

		// lv.addHeaderView(headRe);
		lv.addHeaderView(HeaderVp);

		lv.setOnRefreshListener(new OnRefreshListener() {

			public void loadMoreData() {

				getMoreDate();

			}

			public void updateLVData() {
				initData();

			}
		});

		lv.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				String url = lvList.get(position).url;
				Intent intent = new Intent(mActivity, DetailShowActivity.class);
				intent.putExtra("url", url);
				
				mActivity.startActivity(intent);

			}

		});
		
		
		
		vp.setOnTouchListener(new OnTouchListener() {
			
			public boolean onTouch(View v, MotionEvent event) {
				
				int t = 0;
				switch (event.getAction()) {
				
				
				case MotionEvent.ACTION_DOWN:
					
					mHander.removeMessages(0);
					
					
					
					break;
					
				case MotionEvent.ACTION_CANCEL:
					
					//t=(int) event.getDownTime();
				
					mHander.sendEmptyMessageDelayed(0, 300);
					break;

				
				}
			
				
				
				return false;
			}
		});
		
		return tab_show;

	}

	/*
	 * 对新闻标签页面的数据进行设置；
	 */
	private TabNewsData tabNewsData;
	private TabAdapter vpAdapter;
	private ArrayList<TabVpData> vpList;
	private ArrayList<TabLvData> lvList;
	private LvAdapater lvAdapater;
	private TextView header_title;
	private CirclePageIndicator zhishi;
	private String moreUrl;

	@Override
	public void initData() {

		// System.out.println(tabData.url);

		HttpUtils httpUtils = new HttpUtils();
		final String url=GlobalContants.SERVICE_URL + tabData.url;
		httpUtils.send(HttpMethod.GET,
				url,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						String json = responseInfo.result;
						
						
						NetCacheUtils.addCache(mActivity, url, json);
						
						
						setDataOnConnNetSuccess(json);
						

						

					}

					@Override
					public void onFailure(HttpException error, String msg) {

						System.out.println(msg);
						
						if(!TextUtils.isEmpty(NetCacheUtils.getCache(mActivity, url))){
							setDataOnConnNetSuccess(NetCacheUtils.getCache(mActivity, url));
						}
						lv.completeUpdate();
						Toast.makeText(mActivity, "网络连接失败,请向下滑动尝试刷新操作", 0)
								.show();
					}
				});

	}

	/**
	 * 访问网络成功后 对页面进行数据的设置
	 */
	private void setDataOnConnNetSuccess(String json) {
		
		
		Gson gson = new Gson();

		tabNewsData = gson.fromJson(json, TabNewsData.class);
		moreUrl = tabNewsData.data.more;
		

		vpList = tabNewsData.data.topnews;
		lvList = tabNewsData.data.news;
		// ---------------------------

		vpAdapter = new TabAdapter();
		vp.setAdapter(vpAdapter);

		zhishi.setViewPager(vp);
		header_title.setText(vpList.get(0).title);
		zhishi.setOnPageChangeListener(new VpPagelistener());
		zhishi.onPageSelected(0);

		lvAdapater = new LvAdapater();
		lv.setAdapter(lvAdapater);
		
		mHander.sendEmptyMessageDelayed(0, 3000);
		
		new Thread() {

			public void run() {

				SystemClock.sleep(3000);

				mActivity.runOnUiThread(new Runnable() {

					public void run() {

						lv.completeUpdate();

					}
				});
			};

		}.start();
		

	}

	public class TabAdapter extends PagerAdapter {

		private BitmapUtils bitmapUtils;

		public TabAdapter() {

			bitmapUtils = new BitmapUtils(mActivity);
		}

		@Override
		public int getCount() {

			return vpList.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0 == arg1;
		}

		@Override
		public ImageView instantiateItem(ViewGroup container, int position) {

			ImageView image = new ImageView(mActivity);

			image.setImageResource(R.drawable.ic_launcher);

			image.setScaleType(ImageView.ScaleType.FIT_XY);

			bitmapUtils.display(image, vpList.get(position).topimage);
			// System.out.println(tabNewsData.data.topnews.get(0).url);

			container.addView(image);

			return image;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {

			container.removeView((View) object);
		}
	}

	class LvAdapater extends BaseAdapter {

		private BitmapUtils bitmapUtils;

		public LvAdapater() {
			bitmapUtils = new BitmapUtils(mActivity);
		}

		public int getCount() {
			// TODO Auto-generated method stub
			return lvList.size();
		}

		public TabLvData getItem(int position) {
			// TODO Auto-generated method stub
			return lvList.get(position);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {

			View v = null;

			if (convertView == null) {
				v = View.inflate(mActivity, R.layout.tab_news_lv_item, null);
			} else {
				v = convertView;
			}

			ImageView img = (ImageView) v.findViewById(R.id.tab_lv_img);
			TextView tv = (TextView) v.findViewById(R.id.tab_lv_text);
			TextView date = (TextView) v.findViewById(R.id.tab_lv_date);

			bitmapUtils.display(img, lvList.get(position).listimage);
			tv.setText(lvList.get(position).title);
			date.setText(lvList.get(position).pubdate);
			return v;
		}

	}

	class VpPagelistener implements OnPageChangeListener {

		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub

		}

		public void onPageSelected(int arg0) {

			header_title.setText(vpList.get(arg0).title);

		}

	}

	private void getMoreDate() {

		HttpUtils httpUtils = new HttpUtils();

		if (!TextUtils.isEmpty(moreUrl)) {

			httpUtils.send(HttpMethod.GET,
					GlobalContants.SERVICE_URL + moreUrl,

					new RequestCallBack<String>() {

						@Override
						public void onSuccess(ResponseInfo<String> responseInfo) {
							String json = responseInfo.result;
							Gson gson = new Gson();

							// System.out.println(json);

							TabNewsData tab = gson.fromJson(json,
									TabNewsData.class);

							// System.out.println(tab.data);

							ArrayList<TabLvData> news = tab.data.news;
							moreUrl = tab.data.more;
							// System.out.println(news);

							if (news != null) {

								if (!lvList.contains(news)) {
									lvList.addAll(news);

									new Thread() {

										public void run() {
											SystemClock.sleep(3000);

											mActivity
													.runOnUiThread(new Runnable() {

														public void run() {

															lvAdapater
																	.notifyDataSetChanged();
															lv.completeUpdate();

														}
													});

										};
									}.start();

								}

							}

						}

						@Override
						public void onFailure(HttpException error, String msg) {

							System.out.println(msg);
							lv.completeUpdate();
							Toast.makeText(mActivity, "网络连接失败", 0).show();
						}
					});

		} else {
			Toast.makeText(mActivity, "没有更多了", 0).show();

			lv.completeUpdate();
		}

	}
}
