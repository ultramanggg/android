package com.l.longnews.mainpage.newsTypeImpl;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ActionBar.Tab;
import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.l.longnews.R;
import com.l.longnews.activity.MainActivity;
import com.l.longnews.bean.NewsData.children;
import com.l.longnews.bean.NewsData.typeData;
import com.l.longnews.mainpage.NewsTypeBasePage;
import com.l.longnews.mainpage.newsTabPage.TabShowPage;
import com.viewpagerindicator.TabPageIndicator;

public class NewsPageType extends NewsTypeBasePage implements OnPageChangeListener {

	
	
	private ViewPager vp;
	private ArrayList<children> tabs;
	private ArrayList<TabShowPage> tabViews;
	private TabPageIndicator tabbar;
	private Button next_page;
	public NewsPageType(Activity activity, typeData tpData) {
		super(activity, tpData);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View initView() {
		
		 View showPage = View.inflate(mActivity, R.layout.news_show_page, null);
		
		 vp = (ViewPager) showPage.findViewById(R.id.news_show_vp);
		 
		 tabbar = (TabPageIndicator) showPage.findViewById(R.id.tabbar);
		next_page = (Button) showPage.findViewById(R.id.news_next_page);
		return showPage;
	}
	@Override
	public void initData() {
		
		tabs = tpData.children;
		
		//新闻页面标签栏的标签对应的标签页面  对象  集合创建；
		tabViews = new ArrayList<TabShowPage>();
		
		for(int i=0;i<tabs.size();i++){
			
			TabShowPage tabview = new TabShowPage(mActivity,tabs.get(i));
			
			tabViews.add(tabview);
			
		}
		
		NewsAdapter newsAdapter = new NewsAdapter();
		
		vp.setAdapter(newsAdapter);
		
		tabbar.setViewPager(vp);
		
	
		tabbar.setOnPageChangeListener(this);
		
		
		next_page.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				
				int current_page=vp.getCurrentItem()+1;
				vp.setCurrentItem(current_page);
				
			}
		});
		
		
		updateMainTitle("新闻");
		
	}
	
	class NewsAdapter extends PagerAdapter{
		
		@Override
		public CharSequence getPageTitle(int position) {
			// TODO Auto-generated method stub
			return tabs.get(position).title;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			
			//System.out.println(tabs.size()+"***");
			return tabs.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0==arg1;
		}

		
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			TabShowPage tabShowPage= tabViews.get(position);
			
			View tab = tabShowPage.pageView;
			tabShowPage.initData();
			
			
			container.addView(tab);
			
			return tab;
		}
		
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
		
			container.removeView((View) object);
		}
		
		
	}

	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	public void onPageSelected(int position) {
		MainActivity m=(MainActivity) mActivity;
		
		SlidingMenu slidingMenu = m.getSlidingMenu();
		
		//当处于第一个页面的时候可以打开滑动菜单
		//其他的状态不能打开滑动菜单
		
		if(position==0){
			slidingMenu.setTouchModeAbove(slidingMenu.TOUCHMODE_FULLSCREEN);
		}else{
			slidingMenu.setTouchModeAbove(slidingMenu.TOUCHMODE_NONE);
		}
		
	}
}
