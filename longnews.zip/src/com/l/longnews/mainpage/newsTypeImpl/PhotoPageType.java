package com.l.longnews.mainpage.newsTypeImpl;

import java.security.MessageDigest;
import java.util.ArrayList;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.l.longnews.R;
import com.l.longnews.MyCacheUtils.NetPhotoUtils;
import com.l.longnews.bean.NewsData.children;
import com.l.longnews.bean.NewsData.typeData;
import com.l.longnews.bean.PhotosData;
import com.l.longnews.bean.PhotosData.PhotoInfo;
import com.l.longnews.global.GlobalContants;
import com.l.longnews.mainpage.NewsTypeBasePage;
import com.l.longnews.utils.NetCacheUtils;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

public class PhotoPageType extends NewsTypeBasePage {

	
	
	private ListView lv;
	private GridView gv;
	private ArrayList<children> children;
	private ArrayList<PhotoInfo> plist;

	public PhotoPageType(Activity activity, typeData tpData) {
		
		
		super(activity, tpData);
		
		
	}

	@Override
	public void initData() {
		
		
	
		
		View view = View.inflate(mActivity, R.layout.photo_show, null);
		
		lv = (ListView) view.findViewById(R.id.photo_lv);
		gv = (GridView) view.findViewById(R.id.photo_gv);
		
		page_fl.removeAllViews();
		page_fl.addView(view);
		updateMainTitle("组图");
		
		if(!TextUtils.isEmpty(NetCacheUtils.getCache(mActivity, GlobalContants.PHOTOS_URL))){
			
			parserData(NetCacheUtils.getCache(mActivity, GlobalContants.PHOTOS_URL));
		}
		
		getDataFromServer();
		
		
		
		
	}

	private void getDataFromServer() {
		
		HttpUtils httpUtils = new HttpUtils();
		httpUtils.send(HttpMethod.GET,GlobalContants.PHOTOS_URL,new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				
				String json = responseInfo.result;
				parserData(json);
				NetCacheUtils.addCache(mActivity, GlobalContants.PHOTOS_URL,json);
				
			}

			

			@Override
			public void onFailure(HttpException error, String msg) {
				System.out.println("访问网络失败");
				Toast.makeText(mActivity, "从网络获取数据失败",0).show();
			}
		});
		
	}

	private void parserData(String json) {
		
		Gson gson = new Gson();
		PhotosData photoData = gson.fromJson(json, PhotosData.class);
		plist = photoData.data.news;
		
		if(plist!=null){
			setPageData(plist);
		}
		
		
	}
	
	private void setPageData(ArrayList<PhotoInfo> plist) {
		
		//children = tpData.children;
		//System.out.println("组图的数据"+tpData);
		lvAdpater lvAdpater = new lvAdpater();
		
		lv.setAdapter(lvAdpater);
		
		gv.setAdapter(lvAdpater);
		
	//	String title = children.get(0).title;
		
		
		
	}
	
	@Override
	public void changeLayout(boolean islv) {
		
		if(islv){
			
			lv.setVisibility(lv.VISIBLE);
			gv.setVisibility(gv.GONE);
			
		}else{
			
			lv.setVisibility(lv.GONE);
			gv.setVisibility(gv.VISIBLE);
			
		}
	}
	
	class lvAdpater extends BaseAdapter{
		//BitmapUtils bitmapUtils;
		
		private NetPhotoUtils netPhotoUtils;

		public lvAdpater() {
			//bitmapUtils = new BitmapUtils(mActivity);
			
			netPhotoUtils = new NetPhotoUtils();
		}

		public int getCount() {
			// TODO Auto-generated method stub
			return plist.size();
		}

		public PhotoInfo getItem(int position) {
			
			return plist.get(position);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			
			View v=null;
			
			if(convertView==null){
				
				v=View.inflate(mActivity, R.layout.photo_item,null);
				
			}else{
				v=convertView;
			}
			
			ImageView iv = (ImageView) v.findViewById(R.id.photo_iv);
			TextView tv = (TextView) v.findViewById(R.id.photo_tv);
			
			//bitmapUtils.display(iv,getItem(position).listimage);
			
			netPhotoUtils.display(getItem(position).listimage,iv);
			tv.setText(getItem(position).title);
			
			
			return v;
		}
		
	}
	
}


