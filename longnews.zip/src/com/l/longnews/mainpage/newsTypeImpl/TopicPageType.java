package com.l.longnews.mainpage.newsTypeImpl;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import com.l.longnews.bean.NewsData.typeData;
import com.l.longnews.mainpage.NewsTypeBasePage;

public class TopicPageType extends NewsTypeBasePage {

	
	
	public TopicPageType(Activity activity, typeData tpData) {
		super(activity, tpData);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void initData() {
		
		TextView textView = new TextView(mActivity);
		textView.setText("话题--------类别   ");
		page_fl.addView(textView);
		
		updateMainTitle("话题");
	}
}
