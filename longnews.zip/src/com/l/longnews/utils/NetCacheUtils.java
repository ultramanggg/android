package com.l.longnews.utils;

import android.content.Context;

public class NetCacheUtils {
	
	public static void addCache(Context context,String url,String value){
		PrefUtil.setStringSpValue(context, url, value);
	}
	
	public static String getCache(Context context,String url){
		
		
		
		return PrefUtil.getStringSpValue(context, url,"");
	}

}
