package com.l.longnews.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefUtil {

	public static void setBooleanSpValue(Context context,
			String key, boolean value) {

		SharedPreferences sp = context.getSharedPreferences("config",
				Context.MODE_PRIVATE);

		sp.edit().putBoolean(key, value).commit();

	}

	public static boolean getBooleanSpValue(Context context,
			String key, boolean value) {

		SharedPreferences sp = context.getSharedPreferences("config",
				Context.MODE_PRIVATE);

		return sp.getBoolean(key, value);
	}
	
	public static void setStringSpValue(Context context,
			String key, String value) {

		SharedPreferences sp = context.getSharedPreferences("config",
				Context.MODE_PRIVATE);

		sp.edit().putString(key, value).commit();

	}
	
	
	public static String getStringSpValue(Context context,
			String key, String value) {

		SharedPreferences sp = context.getSharedPreferences("config",
				Context.MODE_PRIVATE);

		return sp.getString(key, value);
	}
}
