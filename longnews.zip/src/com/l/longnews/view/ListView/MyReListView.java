package com.l.longnews.view.ListView;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.l.longnews.R;
import com.l.longnews.activity.DetailShowActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;

public class MyReListView extends ListView implements OnScrollListener {

	private int mPadding;
	// 状态常量
	private static final int STATE_PULL_REFRESH = 0;
	private static final int STATE_RELEASE_REFRESH = 1;
	private static final int STATE_REFRESHING = 2;

	public MyReListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		initHeaderView();
		initFooterView();

	}

	public MyReListView(Context context, AttributeSet attrs) {
		super(context, attrs);

		initHeaderView();
		initFooterView();

	}

	public MyReListView(Context context) {
		super(context);

		initHeaderView();
		initFooterView();
	}

	/**
	 * 初始化顶部的View
	 */
	private void initHeaderView() {

		initAnimation();

		headerView = View.inflate(getContext(),
				R.layout.tab_news_lv_heander_refresh, null);

		jiantou = (ImageView) headerView
				.findViewById(R.id.tab_news_header_jiantou);
		huan = (ProgressBar) headerView.findViewById(R.id.tab_news_header_huan);
		cState = (TextView) headerView
				.findViewById(R.id.tab_news_lv_heander_state);
		date = (TextView) headerView.findViewById(R.id.tab_news_lv_header_date);

		headerView.measure(0, 0);
		mPadding = headerView.getMeasuredHeight();

		headerView.setPadding(0, -mPadding, 0, 0);

		addHeaderView(headerView);

		
	}

	/**
	 * 初始化底部的View
	 */
	private void initFooterView() {

		footer = View.inflate(getContext(), R.layout.tab_news_lv_footer, null);

		footer.measure(0, 0);
		footerHeight = footer.getMeasuredHeight();

		footer.setPadding(0, -footerHeight, 0, 0);

		addFooterView(footer);

		setOnScrollListener(this);
	}

	int x0 = -1;
	int y0 = -1;
	private View headerView;
	private ImageView jiantou;
	private ProgressBar huan;
	private TextView cState;
	private TextView date;

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		
		if(isLoadMore){
			return true;
		}

		if (currentSate == STATE_REFRESHING) {

			return true;
		}

		switch (ev.getAction()) {

		case MotionEvent.ACTION_DOWN:

			y0 = (int) ev.getY();

			break;

		case MotionEvent.ACTION_MOVE:

			if (y0 != -1) {

				int dy = (int) (ev.getY() - y0);

				int padding = -mPadding + dy;

				if (getFirstVisiblePosition() == 0) {

					if (padding > -mPadding) {
						headerView.setPadding(0, padding, 0, 0);
						if (padding > 0) {

							if (currentSate != STATE_RELEASE_REFRESH) {
								refreshState(STATE_RELEASE_REFRESH);
							}

						} else {

							if (currentSate != STATE_PULL_REFRESH) {
								refreshState(STATE_PULL_REFRESH);
							}

						}

					} else {

						break;
					}

					return true;
				}

			}

			break;

		case MotionEvent.ACTION_UP:
			
			y0 = -1;

			if (currentSate == STATE_RELEASE_REFRESH) {

				refreshState(STATE_REFRESHING);

				headerView.setPadding(0, 0, 0, 0);

			} else {

				refreshState(STATE_PULL_REFRESH);
				headerView.setPadding(0, -mPadding, 0, 0);
			}

			break;
		}

		return super.onTouchEvent(ev);
	}

	/**
	 * 更新状态
	 */
	int currentSate = 0;
	private RotateAnimation upAnimation;
	private RotateAnimation downAnimation;

	private void refreshState(int state) {

		currentSate = state;
		switch (state) {

		// 下拉刷新
		case STATE_PULL_REFRESH:

			jiantou.setVisibility(VISIBLE);
			huan.setVisibility(INVISIBLE);
			cState.setText("下拉刷新");

			jiantou.startAnimation(downAnimation);
			break;

		// 释放刷新
		case STATE_RELEASE_REFRESH:

			jiantou.setVisibility(VISIBLE);
			jiantou.startAnimation(upAnimation);
			huan.setVisibility(INVISIBLE);
			cState.setText("松开刷新");
			break;

		// 正在刷新
		case STATE_REFRESHING:

			jiantou.setVisibility(INVISIBLE);
			jiantou.clearAnimation();
			huan.setVisibility(VISIBLE);
			cState.setText("正在刷新");

			// 接口如果设置了则刷新状态更新相关的数据

			if (refreshListener != null) {

				refreshListener.updateLVData();

			}

			break;

		}

	}

	public void initAnimation() {

		upAnimation = new RotateAnimation(0, -180,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		upAnimation.setDuration(200);
		upAnimation.setFillAfter(true);

		downAnimation = new RotateAnimation(-180, -0,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		downAnimation.setDuration(200);
		downAnimation.setFillAfter(true);
	}

	public void completeUpdate() {

		// refreshState(STATE_PULL_REFRESH);

		if (isLoadMore) {

			footer.setPadding(0, -footerHeight, 0, 0);
			isLoadMore = false;

		} else {
			headerView.setPadding(0, -mPadding, 0, 0);

			date.setText(getCurrentTime());

			currentSate = STATE_PULL_REFRESH;

		}

	}

	private String getCurrentTime() {

		SimpleDateFormat format = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		return format.format(new Date());

	}

	OnRefreshListener refreshListener;
	private View footer;
	private int footerHeight;

	public void setOnRefreshListener(OnRefreshListener R) {

		refreshListener = R;
	}

	public interface OnRefreshListener {

		public void updateLVData();

		public void loadMoreData();
	}

	@Override
	public void setOnScrollListener(OnScrollListener l) {
		super.setOnScrollListener(this);

	}

	boolean isLoadMore = false;
	private OnItemClickListener myOnItemClickListener;

	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// SCROLL_STATE_IDLE SCROLL_STATE_FLING SCROLL_STATE_TOUCH_SCROLL
		if (scrollState == SCROLL_STATE_IDLE
				&& getLastVisiblePosition() == getCount() - 1 && !isLoadMore) {

			isLoadMore = true;

			footer.setPadding(0, 0, 0, 0);

			setSelection(getCount());

			if (refreshListener != null) {

				refreshListener.loadMoreData();

			}

		}

	}

	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {

	}

	@Override
	public void setOnItemClickListener(
			final android.widget.AdapterView.OnItemClickListener listener) {
		
		myOnItemClickListener = new OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(!isLoadMore){
					TextView tv = (TextView) view.findViewById(R.id.tab_lv_text);
					tv.setTextColor(Color.GRAY);
				}
				listener.onItemClick(parent, view, position, id);
			}
		};
		
		

		super.setOnItemClickListener(myOnItemClickListener);
	}

}
