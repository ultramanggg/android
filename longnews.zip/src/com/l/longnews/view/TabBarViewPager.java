package com.l.longnews.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class TabBarViewPager extends ViewPager {

	public TabBarViewPager(Context context) {
		super(context);
	}

	public TabBarViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}



}
