package com.l.mobliesafe.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.drm.DrmStore.Action;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import com.l.mobliesafe.R;
import com.l.mobliesafe.utils.SmsUtils;
import com.l.mobliesafe.utils.SmsUtils.GetBackupData;
import com.l.mobliesafe.utils.UIUtils;

public class AToolsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_atools);
		
		
		
		
	}
	
	/**
	 * 
	 * 归属地查询
	 * @param view 
	 */
	public void numberAdressQuery(View v){
		startActivity(new Intent(AToolsActivity.this,AddressActivity.class));
	}
	
	/**
	 * 备份短信
	 * @param v
	 */
	public void backupSms(View v){
		//startActivity(new Intent(AToolsActivity.this,BackUpSmsActivity.class));
		
		final ProgressDialog dialog = new ProgressDialog(AToolsActivity.this);
		
		//dialog.setTitle("提示");
		dialog.setMessage("请稍等,备份中");
		
		dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		
		dialog.show();
		
		new Thread(){
			public void run() {
				
				if(SmsUtils.backUp(AToolsActivity.this,new GetBackupData() {
					
					@Override
					public void getSmsCount(int Count) {
						dialog.setMax(Count);
						
					}
					
					@Override
					public void getBackupCount(int progress) {
						
						dialog.setProgress(progress);
					}
				})){
					UIUtils.showToast(AToolsActivity.this,"备份成功");
					
				}else{
					Looper.prepare();
					Toast.makeText(AToolsActivity.this,"备份失败，请查看当前有没有短息记录", 0).show();
					Looper.loop();
				}
				dialog.dismiss();
			};
			
			
		}.start();
		
		
	}
	
	public void appLock(View v){
		startActivity(new Intent(AToolsActivity.this,AppLockActivity.class));
	}
}
