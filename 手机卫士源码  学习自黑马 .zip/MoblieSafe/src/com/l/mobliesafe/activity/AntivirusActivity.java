package com.l.mobliesafe.activity;

import java.util.ArrayList;
import java.util.List;

import com.l.mobliesafe.R;
import com.l.mobliesafe.db.dao.AntivirusDao;
import com.l.mobliesafe.utils.MD5Utils;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class AntivirusActivity extends Activity {

	protected static final int BEGIN_SCAN = 0;
	protected static final int SCANNING = 1;
	protected static final int END_SCAN = 2;
	
	private boolean IS_SCANNING=false;
	private ImageView scanning;
	private LinearLayout scanning_ly;
	private Button bt_start_scan;
	private ProgressBar pb;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_antivirus);
		
		
		
		initUI();
		initData();
	}
	
	Handler hander=new Handler(){
		
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case BEGIN_SCAN:
				RotateAnimation rotateAnimation = new RotateAnimation(0,360, RotateAnimation.RELATIVE_TO_SELF,0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
				rotateAnimation.setDuration(5000);
				rotateAnimation.setRepeatCount(RotateAnimation.INFINITE);
				scanning.startAnimation(rotateAnimation);
				
				scanning_ly.removeAllViews();
				
				break;
			case SCANNING:
				
				ScanInfo s=(ScanInfo) msg.obj;
				
				TextView textView = new TextView(AntivirusActivity.this);
				
				if(s.isVirus){
					textView.setTextColor(Color.RED);
					textView.setText(s.appName+"：危险");
				}else{
					textView.setTextColor(Color.DKGRAY);
					textView.setText(s.appName+"：安全");
				}
				
				
				scanning_ly.addView(textView);
				
				break;
			case END_SCAN:
				bt_start_scan.setText("开始扫描");
				scanning.clearAnimation();
				IS_SCANNING=false;
				pb.setProgress(0);
				//scanning_ly.removeAllViews();
	
				break;

			default:
				break;
			}
			
			
		};
	};
	private List<String> packageNames;
	
	

	private void initData() {
		packageNames = new ArrayList<String>();	
		
	}

	private void initUI() {
		
		scanning = (ImageView) findViewById(R.id.scanning);
		scanning_ly = (LinearLayout) findViewById(R.id.scanning_ly);
		bt_start_scan = (Button) findViewById(R.id.bt_start_scan);
		pb = (ProgressBar) findViewById(R.id.scanning_pb);
		
	}
	
	static class ScanInfo{
		boolean isVirus=false;
		String appName;
		String packageName;
	}
	
	
	public void startScan(View v){
		
		
		if(IS_SCANNING){
			
			Message msg_end = Message.obtain();
			msg_end.what=END_SCAN;
			hander.sendMessage(msg_end);
			bt_start_scan.setText("开始扫描");
			
		}else{
			IS_SCANNING=true;
			Message msg = Message.obtain();
			msg.what=BEGIN_SCAN;
			hander.sendMessage(msg);
			bt_start_scan.setText("终止扫描");
			
			new Thread(){		
				

				public void run() {
					
					
					
					
					PackageManager packageManager = getPackageManager();
					
					List<PackageInfo> packages = packageManager.getInstalledPackages(0);
					pb.setMax(packages.size());
					
					ScanInfo scanInfo = new ScanInfo();
						
					for (int progress=0;progress<packages.size();progress++) {
						
						PackageInfo packageInfo=packages.get(progress);
						
						if(!IS_SCANNING){
							
							return;
							
						}
						
						
						
						scanInfo.appName = packageInfo.applicationInfo.loadLabel(packageManager).toString();
						scanInfo.packageName = packageInfo.packageName;
						
						String fileMd5 = MD5Utils.getFileMd5(packageInfo.applicationInfo.sourceDir);
						
						//System.out.println(scanInfo.appName+":"+fileMd5);
						String desc = AntivirusDao.scanVitus(fileMd5);

						
						if(desc==null){
							
							scanInfo.isVirus=false;
							
						}else{
							
							
							scanInfo.isVirus=true;
							packageNames.add(scanInfo.packageName);
							
						}
						
						pb.setProgress(progress);
						//通知hander 更新为开始扫描的状态
						Message msg_scanning = Message.obtain();
						msg_scanning.what=SCANNING;
						msg_scanning.obj=scanInfo;
						hander.sendMessage(msg_scanning);
						
						SystemClock.sleep(500);
					}
					
					Message msg_end = Message.obtain();
					msg_end.what=END_SCAN;
					hander.sendMessage(msg_end);
					
				};
				
				
				
			}.start();
			
		}
		
		
	}
	
	public void clearVrius(View v){
		
		
	if(IS_SCANNING){
		
		Toast.makeText(AntivirusActivity.this,"扫描完成后 才能清理", 0).show();
		
	}else{
		
		for (String string : packageNames) {
			
			Intent intetnDelete=new Intent();  
			intetnDelete.setAction(Intent.ACTION_DELETE);  
			intetnDelete.setData(Uri.parse("package:"+string));  
			startActivity(intetnDelete);  
		}
	
		scanning_ly.removeAllViews();
		
		TextView textView = new TextView(AntivirusActivity.this);
		textView.setText("杀毒完成");
		textView.setTextColor(Color.MAGENTA);
		textView.setGravity(Gravity.CENTER);
		scanning_ly.addView(textView);
		
	}	
		
	}
}
