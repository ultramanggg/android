package com.l.mobliesafe.activity;

import com.l.mobliesafe.R;
import com.l.mobliesafe.fragment.AddLockFragment;
import com.l.mobliesafe.fragment.CancelLockFragment;
import com.l.mobliesafe.service.WatchDogService;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AppLockActivity extends FragmentActivity implements OnClickListener {

	private TextView left_tab;
	private TextView right_tab;
	private FragmentTransaction transaction;
	private AddLockFragment addLockFragment;
	private CancelLockFragment cancelLockFragment;
	private FragmentManager fragmentManager;
	private Button swicth;
	private SharedPreferences sp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_app_lock);
		sp = getSharedPreferences("config", MODE_PRIVATE);
		initUI();
		 setAppLockState();
	}

	private void initUI() {

		left_tab = (TextView) findViewById(R.id.lock_left_tab);
		right_tab = (TextView) findViewById(R.id.lock_right_tab);
		swicth = (Button) findViewById(R.id.applock_swicth);

		left_tab.setOnClickListener(this);
		
		right_tab.setOnClickListener(this);
		
		
		addLockFragment = new AddLockFragment();
		cancelLockFragment = new CancelLockFragment();
		
		
		
		fragmentManager = getSupportFragmentManager();
		transaction = fragmentManager.beginTransaction();
		transaction.replace(R.id.lock_fl, addLockFragment).commit();
		
		

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		
		case R.id.lock_left_tab:
			left_tab.setBackgroundResource(R.drawable.lock_left_pressed);
			right_tab.setBackgroundResource(R.drawable.lock_right_default);
			FragmentTransaction transactionleft=fragmentManager.beginTransaction();
			transactionleft.replace(R.id.lock_fl, addLockFragment).commit();
			
			break;
		case R.id.lock_right_tab:
			left_tab.setBackgroundResource(R.drawable.lock_left_default);
			right_tab.setBackgroundResource(R.drawable.lock_right_pressed);
			FragmentTransaction transactionRight=fragmentManager.beginTransaction();
			transactionRight.replace(R.id.lock_fl, cancelLockFragment).commit();
			break;
		default:
			break;
			
		}

	}
	
	public void openAppLock(View v){
		
	
		if(sp.getBoolean("appSwicth",false)){
			
			swicth.setText("开");
			
			stopService(new Intent(AppLockActivity.this,WatchDogService.class));
			sp.edit().putBoolean("appSwicth",false).commit();
			
		}else{
			
			swicth.setText("关");
			startService(new Intent(AppLockActivity.this,WatchDogService.class));
			sp.edit().putBoolean("appSwicth",true).commit();
			
		}
		
	}
	
	public void setAppLockState(){
		if(sp.getBoolean("appSwicth",false)){
			swicth.setText("关");
		}else{			
			swicth.setText("开");
		}
	}

}
