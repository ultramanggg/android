package com.l.mobliesafe.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.l.mobliesafe.R;
import com.l.mobliesafe.R.layout;
import com.l.mobliesafe.bean.AppInfo;
import com.l.mobliesafe.engine.AppInfos;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

public class AppManagerActivity extends Activity implements OnClickListener {

	@ViewInject(R.id.app_lv)
	private ListView lv;
	@ViewInject(R.id.tv_rom)
	private TextView tv_rom;
	@ViewInject(R.id.tv_sd)
	private TextView tv_sd;
	@ViewInject(R.id.app_tv_type)
	private TextView app_type;
	private List<AppInfo> appInfos;
	private List<AppInfo> userApps;
	private List<AppInfo> systemApps;
	private PopupWindow pW;
	private AppInfo appBean;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.avtivity_app_manager);
		init();
		initData();

	}

	Handler mHandler = new Handler() {

		public void handleMessage(Message msg) {

			MyListAdapter myAdapter = new MyListAdapter();

			lv.setAdapter(myAdapter);

		};
	};

	private void initData() {
		new Thread() {

			public void run() {

				appInfos = AppInfos.getAppInfos(AppManagerActivity.this);

				userApps = new ArrayList<AppInfo>();
				systemApps = new ArrayList<AppInfo>();

				for (AppInfo appInfo : appInfos) {

					if (appInfo.isUserApp()) {

						userApps.add(appInfo);

					} else {
						systemApps.add(appInfo);

					}

				}

				mHandler.sendEmptyMessage(0);

			};

		}.start();

	}

	private void init() {
		ViewUtils.inject(this);

		// --------------------------------------------------------------------------
		// 获取rom的剩余空间
		long rom_freeSpace = Environment.getDataDirectory().getFreeSpace();
		// 获取SD卡的剩余空间
		long sd_freeSpace = Environment.getExternalStorageDirectory()
				.getFreeSpace();
		String rom_fs = Formatter.formatFileSize(this, rom_freeSpace);
		String sd_fs = Formatter.formatFileSize(this, sd_freeSpace);

		tv_rom.setText("内存可用：" + rom_fs);
		tv_sd.setText(" SD可用：" + sd_fs);

		// --------------------------------------------------------------------------

		lv.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				popDismiss();
				if (userApps != null && systemApps != null) {
					if (firstVisibleItem < userApps.size() + 1) {

						app_type.setText("用户应用(" + userApps.size() + ")个");

					} else {

						app_type.setText("系统应用(" + systemApps.size() + ")个");

					}

				}
			}
		});

		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Object obj = lv.getItemAtPosition(position);

				if (obj != null && obj instanceof AppInfo) {

					appBean = (AppInfo) obj;

					popDismiss();

					System.out.println("111111111111111");

					View pop_ui = View.inflate(AppManagerActivity.this,
							R.layout.app_popup_window, null);

					ImageView iv_uninstall = (ImageView) pop_ui
							.findViewById(R.id.app_uninstall);
					ImageView iv_start = (ImageView) pop_ui
							.findViewById(R.id.app_start);
					ImageView iv_share = (ImageView) pop_ui
							.findViewById(R.id.app_share);

					iv_uninstall.setOnClickListener(AppManagerActivity.this);
					iv_share.setOnClickListener(AppManagerActivity.this);
					iv_start.setOnClickListener(AppManagerActivity.this);

					// pW.setBackgroundDrawable(new
					// ColorDrawable(Color.TRANSPARENT));

					pW = new PopupWindow(pop_ui, -2, -2);

					int[] location = new int[2];
					view.getLocationInWindow(location);

					pW.showAtLocation(parent, Gravity.LEFT + Gravity.TOP, 70,
							location[1]);
				}
			}
		});

	}

	protected void popDismiss() {
		if (pW != null && pW.isShowing()) {
			pW.dismiss();
			pW = null;
		}

	}

	public class MyListAdapter extends BaseAdapter {

		@Override
		public int getCount() {

			return userApps.size() + systemApps.size() + 2;
		}

		@Override
		public Object getItem(int position) {
			if (position == 0) {
				return null;
			}
			if (position == userApps.size() + 1) {
				return null;
			}
			AppInfo appInfo;

			if (position < userApps.size() + 1) {
				// 把多出来的特殊的条目减掉
				appInfo = userApps.get(position - 1);

			} else {

				int location = userApps.size() + 2;

				appInfo = systemApps.get(position - location);
			}
			return appInfo;

		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View v = null;
			AppInfo appInfo = null;
			if (position == 0) {

				TextView textView = new TextView(AppManagerActivity.this);
				textView.setText("用户应用（" + userApps.size() + ")");
				textView.setBackgroundColor(Color.GRAY);
				textView.setTextColor(Color.WHITE);

				return textView;
			}

			if (position == userApps.size() + 1) {
				TextView textView = new TextView(AppManagerActivity.this);
				textView.setText("系统应用（" + systemApps.size() + ")");
				textView.setBackgroundColor(Color.GRAY);
				textView.setTextColor(Color.WHITE);

				return textView;

			}

			if (position <= userApps.size()) {
				appInfo = userApps.get(position - 1);
			} else {
				appInfo = systemApps.get(position - 2 - userApps.size());
			}

			if (convertView != null && convertView instanceof LinearLayout) {
				v = convertView;

			} else {
				v = View.inflate(AppManagerActivity.this,
						R.layout.app_info_item, null);
			}

			ImageView iv_icon = (ImageView) v.findViewById(R.id.App_info_icon);
			TextView tv_name = (TextView) v.findViewById(R.id.App_info_appName);
			TextView tv_seat = (TextView) v.findViewById(R.id.App_info_seat);
			TextView tv_size = (TextView) v.findViewById(R.id.App_info_size);

			iv_icon.setImageDrawable(appInfo.getIcon());
			tv_name.setText(appInfo.getAppName());

			tv_size.setText(Formatter.formatFileSize(AppManagerActivity.this,
					appInfo.getAppSize()));

			if (appInfo.isRom()) {
				tv_seat.setText("手机内存");
			} else {
				tv_seat.setText("SD卡中");
			}

			return v;
		}

	}

	@Override
	protected void onDestroy() {
		popDismiss();
		super.onDestroy();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.app_uninstall:
			Intent uninstall_localIntent = new Intent(
					"android.intent.action.DELETE", Uri.parse("package:"
							+ appBean.getApkPackageName()));
			startActivity(uninstall_localIntent);
			popDismiss();

			break;

		case R.id.app_start:
			Intent startApp = this.getPackageManager()
					.getLaunchIntentForPackage(appBean.getApkPackageName());
			startActivity(startApp);
			popDismiss();
			break;

		case R.id.app_share:
			Intent share_localIntent = new Intent("android.intent.action.SEND");
            share_localIntent.setType("text/plain");
            share_localIntent.putExtra("android.intent.extra.SUBJECT", "f分享");
            share_localIntent.putExtra("android.intent.extra.TEXT",
                    "Hi！推荐您使用软件：" + appBean.getAppName()+"下载地址:"+"https://play.google.com/store/apps/details?id="+appBean.getApkPackageName());
            this.startActivity(Intent.createChooser(share_localIntent, "分享"));
            popDismiss();
			break;

		default:
			break;
		}

	}
}
