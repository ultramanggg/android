package com.l.mobliesafe.activity;

import com.l.mobliesafe.R;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

/**
 * 设置引导的基类，不需要在清单文件中注册 该页面不需要界面展示
 * 
 * 此类为引导页面的父类，实现了引导页面的相同逻辑，其他的引导
 * 页面继承他 并实现抽象的方法，从而实现不同但又相似的页面。
 * 
 */
public abstract class BaseSetupActivity extends Activity {
	private GestureDetector mDetector;
	public SharedPreferences mPref;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		mPref = getSharedPreferences("config", MODE_PRIVATE);
		mDetector = new GestureDetector(this,
				new GestureDetector.SimpleOnGestureListener() {
					@Override				//e1滑动起点，e2滑动终点。x速度，y速度。
					public boolean onFling(MotionEvent e1, MotionEvent e2,
							float velocityX, float velocityY) {
						
						
						//限制纵向滑动的范围
						if(Math.abs(e1.getRawY()-e2.getRawY())>100){
							return true;
						}
						
						//如果两点间距大于200 则触发事件
						//向右滑，上一页
						
						if(e2.getRawX()-e1.getRawX()>200){
							showPreviouspage();
							return true;
						}
						
						//向左滑,下一页
						
						if(e1.getRawX()-e2.getRawX()>200){
							showNextPage();
							return true;
						}
						
						return super.onFling(e1, e2, velocityX, velocityY);
					}
				});
	}
	//抽象方法必须得到实现
	public abstract void showNextPage();
		//此方法控制页面的向下跳转，需要在子类中实现
	
	public abstract void showPreviouspage();
		//此方法控制页面的向上跳转，需要在子类中实现
	
		
	public void next(View v) {
		showNextPage();

	}
	public void previous(View v) {
		showPreviouspage();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		
		//触摸事件处理方法将  时间信息交给手势识别器处理
		mDetector.onTouchEvent(event);
		return super.onTouchEvent(event);
	}
}
