package com.l.mobliesafe.activity;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.l.mobliesafe.R;
import com.l.mobliesafe.adapter.MyBaseAdaper;
import com.l.mobliesafe.bean.BlackNumberInfo;
import com.l.mobliesafe.db.dao.BlackNumberDao;

public class CallSafeActivity extends Activity {

	private ListView list_view;
	private CallSafeAdapter cSAdapter;
	private ProgressBar pb;
	private TextView tv_page;
	private EditText et_page;

	private List<BlackNumberInfo> nums;

	private int CurrentPageNumber = 1;
	private int totalPage = 1;
	private int PageSize = 6;
	private BlackNumberDao mNumDao;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_call);
		mNumDao = new BlackNumberDao(CallSafeActivity.this);
		initUI();
		initData();

	}

	/**
	 * handler对adapter进行界面的更新操作；
	 * 
	 * 
	 *  if(adapter == null){
                adapter = new CallSafeAdapter(blackNumberInfos, CallSafeActivity.this);
                list_view.setAdapter(adapter);
            }else{
                adapter.notifyDataSetChanged();
            }
	 */
	private Handler myhandler = new Handler() {
		public void handleMessage(android.os.Message msg) {

			pb.setVisibility(View.INVISIBLE);// 将progressBar关闭显示
			tv_page.setText(CurrentPageNumber + "/" + totalPage);
			
			
				cSAdapter = new CallSafeAdapter(nums, CallSafeActivity.this);
				list_view.setAdapter(cSAdapter);
			

			
		};
	};

	/**
	 * 初始化Ui显示数据
	 */
	private void initData() {

		new Thread() {

			public void run() {

				totalPage = mNumDao.getTotalNumber() / PageSize;

				nums = mNumDao.findPage(CurrentPageNumber, PageSize);

				myhandler.sendEmptyMessage(0);
			};
		}.start();

	}

	/**
	 * 初始化UI
	 */
	private void initUI() {
		// 初始化 等待圆圈
		pb = (ProgressBar) findViewById(R.id.call_pb);
		pb.setVisibility(View.VISIBLE);
		// 初始化页码相关控件

		tv_page = (TextView) findViewById(R.id.call_tv_page);
		et_page = (EditText) findViewById(R.id.call_et_page);

		list_view = (ListView) findViewById(R.id.list_view);

	}

	/**
	 * 电话号码显示的适配器
	 * 
	 * @author huawe p7
	 * 
	 */
	public class CallSafeAdapter extends MyBaseAdaper<BlackNumberInfo> {

		public CallSafeAdapter(List<BlackNumberInfo> list, Context context) {
			super(list, context);
			// TODO Auto-generated constructor stub
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View v;

			if (convertView == null) {
				v = View.inflate(CallSafeActivity.this,
						R.layout.call_list_item, null);
			} else {
				v = convertView;
			}

			TextView tv_Num = (TextView) v.findViewById(R.id.Black_Num);

			tv_Num.setText(mlist.get(position).getNumber());

			TextView tv_mode = (TextView) v.findViewById(R.id.Black_Mode);

			if (mlist.get(position).getMode().equals("1")) {
				tv_mode.setText("来电拦截");
			} else if (mlist.get(position).getMode().equals("2")) {
				tv_mode.setText("短信拦截");
			} else {
				tv_mode.setText("完全拦截");
			}

			return v;
		}

	}

	public void callPreviousPage(View v) {
		if (CurrentPageNumber <= 0) {
			return;
		}

		CurrentPageNumber--;

		initData();

	}

	public void callNextPage(View v) {

		if (CurrentPageNumber >= totalPage) {
			return;
		}

		CurrentPageNumber++;
		initData();
	}

	public void callJumpPage(View v) {
		String page = et_page.getText().toString().trim();
		int p = Integer.valueOf(page);

		if (p > 0 && p <= totalPage) {
			CurrentPageNumber = p;

			initData();
		}

	}

	public void delNum(View v) {

		mNumDao.deleteBlackNum("");
		View parent = (View) v.getParent();
		TextView tv = (TextView) parent.findViewById(R.id.Black_Num);
		mNumDao.deleteBlackNum(tv.getText().toString().trim());

		initData();
	}

	public void modifyMode(View v) {

		final String[] modes = new String[] { "来电拦截", "短信拦截", "完全拦截" };

		View parent = (View) v.getParent();
		final TextView tv = (TextView) parent.findViewById(R.id.Black_Num);

		Builder builder = new AlertDialog.Builder(CallSafeActivity.this);
		builder.setItems(modes, new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// System.out.println(modes[which]+which);

				mNumDao.changeNumMode(tv.getText().toString().trim(),
						String.valueOf(which + 1));

				initData();
				dialog.dismiss();
			}
		});

		builder.show();

	}

	public void insertNum(View v) {

		final AlertDialog.Builder builder = new AlertDialog.Builder(this);
		final View v1 = View.inflate(this, R.layout.edit_dialog, null);
	
		builder.setView(v1);
		
		RadioGroup rg = (RadioGroup) v1.findViewById(R.id.dialog_call_rg);
		
		builder.setNegativeButton("确定", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				String mode="1";
				EditText et=(EditText) v1.findViewById(R.id.et_pNum);
				String pNum = et.getText().toString();
			
				RadioButton rb2=(RadioButton) v1.findViewById(R.id.rb2);
				RadioButton rb3=(RadioButton) v1.findViewById(R.id.rb3);
				if(rb2.isChecked()){
					mode="2";
				}
				
				if(rb3.isChecked()){
					mode="3";
				}
				if(!pNum.equals("")){
				mNumDao.addBlackNum(pNum, mode);
				initData();
				}else{
					Toast.makeText(CallSafeActivity.this,"电话号码不能为空", 0).show();
				}
			}
		});
		builder.setPositiveButton("取消", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				builder.create().dismiss();
			}
		});
		
		builder.show();
		String modes;	
		
		
		
	}

}
