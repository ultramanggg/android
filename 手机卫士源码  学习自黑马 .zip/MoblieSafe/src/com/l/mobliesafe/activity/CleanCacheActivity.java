package com.l.mobliesafe.activity;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.l.mobliesafe.R;

import android.R.integer;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageDataObserver;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.PackageStats;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.format.Formatter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class CleanCacheActivity extends Activity {

	private ListView lv;
	private Button cleanAll;
	private PackageManager packageManager;
	private List<AppCacheInfo> appCaheInfos;
	private Myadapter myadapter;
	private LinearLayout ll;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_cache);

		init();
		initData();
	}

	private void initData() {

		getCache();

	}

	private void init() {
		ll = (LinearLayout) findViewById(R.id.clean_cache_xz);
		lv = (ListView) findViewById(R.id.lv_cache);
		cleanAll = (Button) findViewById(R.id.bt_cleanAll_cache);

	}

	private void getCache() {

		packageManager = getPackageManager();

		final List<PackageInfo> installedPackages = packageManager
				.getInstalledPackages(0);
		appCaheInfos = new ArrayList<AppCacheInfo>();

		new Thread() {

			public void run() {
				
				SystemClock.sleep(3000);
				
				MyIPackageStatsObserver myIPackageStatsObserver = new MyIPackageStatsObserver();

				for (PackageInfo packageInfo : installedPackages) {

					String packageName = packageInfo.packageName;

					try {

						Method method = packageManager.getClass()
								.getDeclaredMethod("getPackageSizeInfo",
										String.class,
										IPackageStatsObserver.class);

						method.invoke(packageManager, packageName,
								myIPackageStatsObserver);

					} catch (Exception e) {
						e.printStackTrace();
					}

				}

				runOnUiThread(new Runnable() {
					public void run() {
						ll.setVisibility(View.INVISIBLE);
						myadapter = new Myadapter();
						lv.setAdapter(myadapter);

					}
				});
			};

		}.start();

	}

	class MyIPackageStatsObserver extends IPackageStatsObserver.Stub {

		@Override
		public void onGetStatsCompleted(PackageStats pStats, boolean succeeded)
				throws RemoteException {

			long cacheSize = pStats.cacheSize;

			String packageName = pStats.packageName;

			// System.out.println(""+cacheSize+":"+packageName);

			if (cacheSize > 0) {

				try {
					AppCacheInfo cacheInfo = new AppCacheInfo();

					cacheInfo.icon = packageManager
							.getApplicationIcon(packageName);
					cacheInfo.packageName=packageName;
					ApplicationInfo applicationInfo = packageManager
							.getApplicationInfo(packageName, 0);
					cacheInfo.name = packageManager.getApplicationLabel(
							applicationInfo).toString();
					cacheInfo.size = cacheSize;

					appCaheInfos.add(cacheInfo);

				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		}

	}

	class Myadapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return appCaheInfos.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return appCaheInfos.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView == null) {
				v = View.inflate(CleanCacheActivity.this, R.layout.item_cache,
						null);
			} else {
				v = convertView;
			}

			ImageView appicon = (ImageView) v.findViewById(R.id.cache_icon);
			TextView appname = (TextView) v.findViewById(R.id.cache_name);
			TextView appsize = (TextView) v.findViewById(R.id.cache_size);
			ImageView appClean = (ImageView) v.findViewById(R.id.cache_clean);

			appicon.setImageDrawable(appCaheInfos.get(position).icon);

			appname.setText(appCaheInfos.get(position).name);
			appsize.setText(Formatter.formatFileSize(CleanCacheActivity.this,
					appCaheInfos.get(position).size));
			
			appClean.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
//					try {
//						//Method method = packageManager.getClass().getDeclaredMethod("deleteApplicationCacheFiles",String.class,MyIPackageDataObserver.class);
//					
//						
//						
//						Method[] methods = packageManager.getClass().getMethods();
//						for (Method method3 : methods) {
//							
//							if(method3.getName().equals("deleteApplicationCacheFiles")){
//								
//								method3.invoke(packageManager,appCaheInfos.get(position).packageName,new MyIPackageDataObserver());
//							}
//							
//						}
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
					Intent localIntent = new Intent();
			        localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			        if (Build.VERSION.SDK_INT >= 9) {
			            localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
			            localIntent.setData(Uri.fromParts("package", getPackageName(), null));
			        } else if (Build.VERSION.SDK_INT <= 8) {
			            localIntent.setAction(Intent.ACTION_VIEW);
			            localIntent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
			            localIntent.putExtra("com.android.settings.ApplicationPkgName", getPackageName());
			        }
			        startActivity(localIntent);
					
//					
				}
			});

			return v;
		}

	}

	static class AppCacheInfo {

		Drawable icon;
		long size;
		String name;
		String packageName;
	}

	

	public void cleanAll(View v) {

		MyIPackageDataObserver myIPackageDataObserver = new MyIPackageDataObserver();

		Method[] methods = packageManager.getClass().getMethods();

		for (Method method2 : methods) {

			
			if (method2.getName().equals("freeStorageAndNotify")) {
				
				try {
					method2.invoke(packageManager, Integer.MAX_VALUE,
							myIPackageDataObserver);
					appCaheInfos.clear();
					myadapter.notifyDataSetChanged();
				} catch (Exception e) {
					System.out.println("方法没有找到");
				}
			}
		}

	}

	class MyIPackageDataObserver extends IPackageDataObserver.Stub {

		@Override
		public void onRemoveCompleted(String packageName, boolean succeeded)
				throws RemoteException {

			System.out.println(packageName);
		}

	}
}
