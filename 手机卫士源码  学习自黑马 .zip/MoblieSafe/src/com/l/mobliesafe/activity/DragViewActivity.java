package com.l.mobliesafe.activity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.l.mobliesafe.R;

public class DragViewActivity extends Activity {

	private TextView tvTop;
	private TextView tvBottom;
	
	private ImageView ivDrag;
	private SharedPreferences mPref;
	private int winWidth;
	private int winHeight;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dragview);
		
		mPref = getSharedPreferences("config", MODE_PRIVATE);
		
		tvTop = (TextView) findViewById(R.id.tv_top);
		tvBottom = (TextView) findViewById(R.id.tv_bottom);
		ivDrag = (ImageView) findViewById(R.id.iv_drag);
		
		
		
		winWidth = getWindowManager().getDefaultDisplay().getWidth();
		winHeight = getWindowManager().getDefaultDisplay().getHeight();
		

		RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams)ivDrag.getLayoutParams();

		params.leftMargin = mPref.getInt("l", 0);
		params.topMargin = mPref.getInt("t",0);
		
		

		if(mPref.getInt("t",0)< (winHeight-30)/2){
			tvBottom.setVisibility(View.VISIBLE);
			tvTop.setVisibility(View.INVISIBLE);
		}else{
			tvBottom.setVisibility(View.INVISIBLE);
			tvTop.setVisibility(View.VISIBLE);
		}
		
		ivDrag.setLayoutParams(params);
		
		ivDrag.setOnClickListener(new OnClickListener() {
			
		
			long[] mHits = new long[2];// 数组长度表示要点击的次数

			public void onClick(View view) {
				System.arraycopy(mHits, 1, mHits, 0, mHits.length - 1);
				mHits[mHits.length - 1] = SystemClock.uptimeMillis();// 开机后开始计算的时间
				if (mHits[0] >= (SystemClock.uptimeMillis() - 500)) {
					ivDrag.layout(winWidth/2-ivDrag.getWidth()/2, ivDrag.getTop(), winWidth/2+ivDrag.getWidth()/2, ivDrag.getBottom());
					
					mPref.edit().putInt("l", ivDrag.getLeft()).commit();
					mPref.edit().putInt("t", ivDrag.getTop()).commit();
				}
			}
		});
		
		ivDrag.setOnTouchListener(new OnTouchListener() {
			
			private int startX;
			private int stratY;
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:

					startX = (int) event.getRawX();
					stratY = (int) event.getRawY();

					break;
				case MotionEvent.ACTION_MOVE:

					int endX = (int) event.getRawX();
					int endY = (int) event.getRawY();

					int dx = endX - startX;
					int dy = endY - stratY;
					
					int l = ivDrag.getLeft() + dx;
					int r = ivDrag.getRight() + dx;
					int t = ivDrag.getTop() + dy;
					int b = ivDrag.getBottom() + dy;
					
					if(l<0||r>winWidth||t<0||b>winHeight-30){
						break;
					}	
					if(t < (winHeight-30)/2){
						tvBottom.setVisibility(View.VISIBLE);
						tvTop.setVisibility(View.INVISIBLE);
					}else{
						tvBottom.setVisibility(View.INVISIBLE);
						tvTop.setVisibility(View.VISIBLE);
					}
					ivDrag.layout(l, t, r, b);
					
					
					startX = (int) event.getRawX();
					stratY = (int) event.getRawY();
					break;
				case MotionEvent.ACTION_UP:
					
					mPref.edit().putInt("l", ivDrag.getLeft()).commit();
					mPref.edit().putInt("t", ivDrag.getTop()).commit();

					break;
				default:
					break;
				}
				return false;//控制时间是否往下传递，false：onclick才能获取到事件
			}
		});
	}
}
