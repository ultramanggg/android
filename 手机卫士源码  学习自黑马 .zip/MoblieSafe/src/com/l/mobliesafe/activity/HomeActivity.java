package com.l.mobliesafe.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.TrafficStats;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.TextureView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.l.mobliesafe.R;
import com.l.mobliesafe.utils.MD5Utils;

/**
 * 主页面
 * 
 * @author 詹帅龙
 * 
 */
public class HomeActivity extends Activity {

	private GridView gvHome;

	private String[] mItems = new String[] {
										   "手机防盗","通讯卫士","软件管理",
										   "进程管理","流量统计","手机杀毒",
										   "缓存清理","高级工具","设置更新",
											};
	
	private int[] mPics =new int[]
	{
	 R.drawable.home_safe,       R.drawable.home_callmsgsafe, R.drawable.home_apps,
	 R.drawable.home_taskmanager,R.drawable.home_netmanager,  R.drawable.home_trojan,
	 R.drawable.home_sysoptimize,R.drawable.home_tools,       R.drawable.home_settings
	 };

	private SharedPreferences mPref;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		mPref = getSharedPreferences("config", MODE_PRIVATE);
		
		gvHome = (GridView) findViewById(R.id.gv_home);
		gvHome.setAdapter(new HomeAdapter());
		gvHome.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				//System.out.println("["+position+"]:"+mItems[position]);
				switch (position) {
				case 0:
					
						showPasswordDialog();
					
					break;
				case 1:
					startActivity(new Intent(HomeActivity.this,CallSafeActivity.class));

				break;
				case 2:
					startActivity(new Intent(HomeActivity.this,AppManagerActivity.class));

				break;
				case 3:
					startActivity(new Intent(HomeActivity.this,TaskManagerActivity.class));

				break;
				case 4:
					startActivity(new Intent(HomeActivity.this,TrafficActivity.class));

				break;
				
				case 5:
					startActivity(new Intent(HomeActivity.this,AntivirusActivity.class));

				break;
				case 6:
					startActivity(new Intent(HomeActivity.this,CleanCacheActivity.class));

				break;
				case 7:
					//跳转到设置中心
					
					startActivity(new Intent(HomeActivity.this,AToolsActivity.class));
					break;
				
				case 8:
					//跳转到设置中心
					
					startActivity(new Intent(HomeActivity.this,SettingActivity.class));
					break;

				default:
					break;
				}
				
			}
		});
	}
	
	/**
	 *判断之前是否设置了密码
	 *如何没有弹出设置密码弹窗
	 *出国设置了弹出输入密码的弹窗
	 */
	protected void showPasswordDialog(){
		String savePassword=mPref.getString("password", null);
		if(savePassword!=null){
			showPasswordinputDialog();
		}else{
			showPasswordsetDialog();
		}
		
	}
	
	/**
	 * 输入密码的弹出窗
	 */
	private void showPasswordinputDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		final AlertDialog dialog = builder.create();
		
		View view =View.inflate(this,R.layout.dailog_input_password,null);
		
		dialog.setView(view, 0, 0, 0, 0);//设定边距为0， 保证在2.3的系统中运行的完美
		dialog.show();
		
		Button btnOK=(Button) view.findViewById(R.id.btn_ok);
		Button btnCancel=(Button) view.findViewById(R.id.btn_cancel);
		
		
		final EditText etPassword=(EditText) view.findViewById(R.id.et_password);
		//设置监听
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String inputPassword=MD5Utils.encode(etPassword.getText().toString());
				
				String savePassword=mPref.getString("password", null);
				
				if(inputPassword.equals(savePassword)){
				Toast.makeText(HomeActivity.this, "密码正确", 0).show();
				dialog.dismiss();
				
				//跳转到手机防盗的页面
				
				startActivity(new Intent(HomeActivity.this,LostFindActivity.class));
				
				}else{
					Toast.makeText(HomeActivity.this, "密码不正确", 1).show();	
				}
			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				dialog.dismiss();
				
			}
		});
		
	}

	/**
	 * 设置密码弹窗
	 */
	protected void showPasswordsetDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		final AlertDialog dialog = builder.create();
		
		View view =View.inflate(this,R.layout.dailog_set_password,null);
		
		//dialog.setView(view);//将布局文件设置给他
		dialog.setView(view, 0, 0, 0, 0);//设定边距为0， 保证在2.3的系统中运行的完美
		dialog.show();
		
		//获取控件
		
		Button btnOK=(Button) view.findViewById(R.id.btn_ok);
		Button btnCancel=(Button) view.findViewById(R.id.btn_cancel);
		
		final EditText etPassword=(EditText) view.findViewById(R.id.et_password);
		final EditText etConfirm=(EditText) view.findViewById(R.id.et_password_confirm);
		//设置监听
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String password=etPassword.getText().toString();
				String confirm=etConfirm.getText().toString();
				if(!TextUtils.isEmpty(confirm)&&!TextUtils.isEmpty(password)){
					if(password.equals(confirm)){
						Toast.makeText(HomeActivity.this,"密码设置成功", 1).show();
						mPref.edit().putString("password",MD5Utils.encode(password)).commit();
						
						dialog.dismiss();
						
						//跳转到手机防盗的页面
						startActivity(new Intent(HomeActivity.this,LostFindActivity.class));
					}else{
						Toast.makeText(HomeActivity.this,"输入的密码不一致请重新输入", 1).show();
					}
					
				}else{
					Toast.makeText(HomeActivity.this,"输入的密码不能是空的", 1).show();
				}
			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				dialog.dismiss();
				
			}
		});
	
	}

	/**
	 * 主页面的适配器类
	 * @author huawe p7
	 *
	 */
	class HomeAdapter extends BaseAdapter {

		@Override
		public int getCount() {

			return mItems.length;
		}

		@Override
		public Object getItem(int position) {

			return mItems[position];
		}

		@Override
		public long getItemId(int position) {

			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View view = View.inflate(HomeActivity.this,R.layout.home_list_item, null);

			ImageView ivItem = (ImageView) view.findViewById(R.id.iv_item);
			TextView tvItem = (TextView) view.findViewById(R.id.tv_item);
			
			
			tvItem.setText(mItems[position]);
			ivItem.setImageResource(mPics[position]);
			
			return view;
		}

	}
}
