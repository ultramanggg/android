package com.l.mobliesafe.activity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.l.mobliesafe.R;

public class LockInputActivity extends Activity {
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_lock_input);
		
		initUI();
		
	}

	private void initUI() {
		
		
		final EditText psw=(EditText) findViewById(R.id.et_password_lock);
		
		final TextView bt_0 = (TextView) findViewById(R.id.bt_0);
		final TextView bt_1 = (TextView) findViewById(R.id.bt_1);
		final TextView bt_2 = (TextView) findViewById(R.id.bt_2);
		final TextView bt_3 = (TextView) findViewById(R.id.bt_3);
		final TextView bt_4 = (TextView) findViewById(R.id.bt_4);
		final TextView bt_5 = (TextView) findViewById(R.id.bt_5);
		final TextView bt_6 = (TextView) findViewById(R.id.bt_6);
		final TextView bt_7 = (TextView) findViewById(R.id.bt_7);
		final TextView bt_8 = (TextView) findViewById(R.id.bt_8);
		final TextView bt_9 = (TextView) findViewById(R.id.bt_9);
		
		
		bt_0.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_0.getText().toString());
				
			}
		});
		
		bt_1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_1.getText().toString());
				
			}
		});
		
		bt_2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_2.getText().toString());
				
			}
		});
		
		bt_3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_3.getText().toString());
				
			}
		});
		bt_4.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_4.getText().toString());
				
			}
		});
		bt_5.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_5.getText().toString());
				
			}
		});
		bt_6.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_6.getText().toString());
				
			}
		});
		
		bt_9.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_9.getText().toString());
				
			}
		});
		bt_7.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_7.getText().toString());
				
			}
		});
		bt_8.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				psw.setText(str+bt_8.getText().toString());
				
			}
		});
	
		
		Button clean = (Button) findViewById(R.id.bt_clean);
		Button confirm = (Button) findViewById(R.id.bt_confirm);
		Button del = (Button) findViewById(R.id.bt_del);
		
		
		
		del.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String str = psw.getText().toString();
				if(str.length()<=0){
					return;
				}
				
				psw.setText(str.substring(0, str.length()-1));
				
			}
		});
		
		clean.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				psw.setText("");
				
			}
		});
		
		confirm.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(psw.getText().toString().equals("123")){
					
					
					finish();
				}
				
			}
		});
		
	}
	
	@Override
	public void onBackPressed() {
		
		//super.onBackPressed();
		Toast.makeText(LockInputActivity.this,"请输入密码", 0).show();
		
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		
	}

}
