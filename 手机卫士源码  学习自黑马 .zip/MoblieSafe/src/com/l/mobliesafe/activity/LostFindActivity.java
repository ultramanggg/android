package com.l.mobliesafe.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.l.mobliesafe.R;

/**
 * 手机防盗页面
 * @author huawe p7
 *
 */
public class LostFindActivity extends Activity {

	private SharedPreferences mPref;
	private TextView tvSafePNum;
	private TextView tvProtect;
	private ImageView ivlock;
	private String savePhone;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		mPref = getSharedPreferences("config", MODE_PRIVATE);
		
		savePhone = mPref.getString("safePhone","");
			
		boolean configed=mPref.getBoolean("configed", false);
		//判断是否是首次进入 如果是首次进入则 跳转到设置向导的页面，如果不是则进入这页面
		if(configed){
			setContentView(R.layout.activity_lost_find);
			tvSafePNum = (TextView) findViewById(R.id.tv_safePhone1);
			tvProtect = (TextView) findViewById(R.id.tv_protect);
			ivlock = (ImageView) findViewById(R.id.iv_lock);
			
			
			tvSafePNum.setText(savePhone);
			
			
			if(mPref.getBoolean("safe", true)){
				tvProtect.setText("安全防护已开启");
				ivlock.setImageResource(R.drawable.lock);
				
			}else{
				tvProtect.setText("安全防护已关闭");

				ivlock.setImageResource(R.drawable.unlock);
			}
			
		}else{
			
			startActivity(new Intent(LostFindActivity.this, SetUp1Activity.class));
			finish();
		}
	}
	
	public void reEnter(View v){
		
		startActivity(new Intent(LostFindActivity.this, SetUp1Activity.class));
		
	}
}
