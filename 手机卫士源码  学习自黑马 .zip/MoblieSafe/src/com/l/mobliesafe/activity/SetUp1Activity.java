package com.l.mobliesafe.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.l.mobliesafe.R;

public class SetUp1Activity extends BaseSetupActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup1);
	}
	
	
	@Override
	public void showNextPage() {
		startActivity(new Intent(this,SetUp2Activity.class));
		finish();
		
		overridePendingTransition(R.anim.tran_in,R.anim.tran_out);
		
	}

	@Override
	public void showPreviouspage() {
		
		
	}
}
