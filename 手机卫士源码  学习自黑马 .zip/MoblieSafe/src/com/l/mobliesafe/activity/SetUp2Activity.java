package com.l.mobliesafe.activity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.l.mobliesafe.R;
import com.l.mobliesafe.view.SettingItemView;

public class SetUp2Activity extends BaseSetupActivity {
	
	private SettingItemView sivSim;
	private String sim;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup2);
		
		sivSim = (SettingItemView) findViewById(R.id.siv_sim); 
		
		sim = mPref.getString("sim", "");
		
		if("".equals(sim)){
			
			sivSim.setCheckBoxStatus(false);
		}else{
			
			sivSim.setCheckBoxStatus(true);
		}
		
		
		sivSim.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(sivSim.isChecked()){
					
					
					mPref.edit().remove("sim").commit();
					sivSim.setCheckBoxStatus(false);
				}else{
					
					
					TelephonyManager tm= (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
					String simSeriaNumber = tm.getSimSerialNumber();
					
					mPref.edit().putString("sim", simSeriaNumber).commit();
					
					sivSim.setCheckBoxStatus(true);
				}
				
			}
		});
	}
	
	public void showNextPage(){
		
		if(TextUtils.isEmpty(mPref.getString("sim", ""))){
			
		Toast.makeText(SetUp2Activity.this, "必须绑定才能继续进行", 0).show();
			return;
		}
		startActivity(new Intent(this, SetUp3Activity.class));

		finish();
		overridePendingTransition(R.anim.tran_in, R.anim.tran_out);
		
	}
	public void showPreviouspage(){
		startActivity(new Intent(this, SetUp1Activity.class));
		finish();

		overridePendingTransition(R.anim.tran_previous_in,
				R.anim.tran_previous_out);
	}
}
