package com.l.mobliesafe.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.l.mobliesafe.R;

public class SetUp3Activity extends BaseSetupActivity {
	private EditText etPhone;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup3);
		
		String savePhone= mPref.getString("safePhone","");
		
		etPhone = (EditText) findViewById(R.id.et_phone);
		
			etPhone.setText(savePhone);
		
	}
	
	

	@Override
	public void showNextPage() {
		String safePnum=etPhone.getText().toString().trim();
		
		if(TextUtils.isEmpty(safePnum)){
			Toast.makeText(SetUp3Activity.this,"请选择安全号码后再进行",0).show();
			return;
		}
		
		mPref.edit().putString("safePhone",safePnum).commit();
		
		startActivity(new Intent(SetUp3Activity.this,SetUp4Activity.class));
		finish();
		overridePendingTransition(R.anim.tran_in,R.anim.tran_out);
	}

	@Override
	public void showPreviouspage() {
		startActivity(new Intent(SetUp3Activity.this,SetUp2Activity.class));
		
		finish();
		
		overridePendingTransition(R.anim.tran_previous_in,R.anim.tran_previous_out);
	}
	
	
	public void selectContact(View v){
		
		Intent intent = new Intent(this,ContactActivity.class);
		
		startActivityForResult(intent, 0);
		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		if(resultCode==RESULT_OK){
		
			String phone=data.getStringExtra("phone");	
			phone=phone.replaceAll("-","").replaceAll(" ", "");
			etPhone.setText(phone);
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
}
