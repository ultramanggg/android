package com.l.mobliesafe.activity;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;

import com.l.mobliesafe.R;
import com.l.mobliesafe.utils.DeviceManageUtils;
import com.lidroid.xutils.db.annotation.Check;

public class SetUp4Activity extends BaseSetupActivity {

	private CheckBox cbSafe;
	private ImageView ivLock;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setup4);
		ivLock = (ImageView) findViewById(R.id.iv_LockOrUnlock);
		cbSafe = (CheckBox) findViewById(R.id.cb_safe);
		
	
		
		if(mPref.getBoolean("safe", true)){
			
			cbSafe.setText("手机防盗已开启");		
			cbSafe.setChecked(true);
			mPref.edit().putBoolean("safe", true).commit();
			ivLock.setImageResource(R.drawable.lock);
			
			
			
		}else{
			

				cbSafe.setText("手机防盗已关闭");
				ivLock.setImageResource(R.drawable.unlock);
				mPref.edit().putBoolean("safe",false).commit();
				
		}
	}

	@Override
	public void showNextPage() {
		
		
		
		
		startActivity(new Intent(SetUp4Activity.this, LostFindActivity.class));
		
		
		
		finish();

		mPref.edit().putBoolean("configed", true).commit();
	}

	@Override
	public void showPreviouspage() {
		startActivity(new Intent(SetUp4Activity.this, SetUp3Activity.class));

		finish();
		overridePendingTransition(R.anim.tran_previous_in,
				R.anim.tran_previous_out);
	}

	public void OKorNo(View v) {

	
			if (cbSafe.isChecked()) {
				
				//激活设备管理器
				DeviceManageUtils.activeDeviceManage(SetUp4Activity.this);
				
				cbSafe.setText("手机防盗已开启");
				ivLock.setImageResource(R.drawable.lock);
				mPref.edit().putBoolean("safe", true).commit();
				
				
			} else {

				cbSafe.setText("手机防盗已关闭");
				ivLock.setImageResource(R.drawable.unlock);
				mPref.edit().putBoolean("safe",false).commit();
				
				//取消设备管理器的激活
				DeviceManageUtils.cancelDeviceManage(SetUp4Activity.this);
			
			}
		
	}
}
