package com.l.mobliesafe.activity;

import android.app.Activity;
import android.app.AlertDialog;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.l.mobliesafe.R;
import com.l.mobliesafe.service.AddressService;
import com.l.mobliesafe.service.CallSafeService;
import com.l.mobliesafe.service.WatchDogService;
import com.l.mobliesafe.utils.ServiceStatusUtils;
import com.l.mobliesafe.utils.SystemInfoUtils;
import com.l.mobliesafe.view.SettingClickView;
import com.l.mobliesafe.view.SettingItemView;

/**
 * 
 * 设置中心的
 * 
 * @author huawe p7
 * 
 */
public class SettingActivity extends Activity {
	private SettingItemView sivUpdate;
	private SharedPreferences mPref;
	private SettingItemView sivAddress;
	private SettingClickView scvToastAddress;
	private SettingClickView scvAddressLocation;
	private SettingItemView sivblack;
	private SettingItemView watch_dog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);

		mPref = getSharedPreferences("config", MODE_PRIVATE);

		initAutoUpdateView();
		initAddressView();
		initAddressTheme();
		initAddressLoacation();
		initBlackcontacts();
		initWatchDog();
	}

	/**
	 * 初始化黑名单设置
	 */
	private void initBlackcontacts() {
		sivblack = (SettingItemView) findViewById(R.id.siv_black);

		if (mPref.getBoolean("blackContacts", true)) {

			sivblack.setCheckBoxStatus(true);
		} else {

			sivblack.setCheckBoxStatus(false);
		}

		sivblack.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (sivblack.isChecked()) {

					sivblack.setCheckBoxStatus(false);

					mPref.edit().putBoolean("blackContacts", false).commit();
					
					stopService(new Intent(SettingActivity.this,
							CallSafeService.class));

				} else {

					sivblack.setCheckBoxStatus(true);

					mPref.edit().putBoolean("blackContacts", true).commit();
					
					startService(new Intent(SettingActivity.this,
							CallSafeService.class));
				}

			}
		});

	}

	/**
	 * 初始化自动更新的方法
	 */
	public void initAutoUpdateView() {

		sivUpdate = (SettingItemView) findViewById(R.id.siv_update);

		if (mPref.getBoolean("auto_update", true)) {

			sivUpdate.setCheckBoxStatus(true);
		} else {

			sivUpdate.setCheckBoxStatus(false);
		}

		sivUpdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (sivUpdate.isChecked()) {

					sivUpdate.setCheckBoxStatus(false);

					mPref.edit().putBoolean("auto_update", false).commit();

				} else {

					sivUpdate.setCheckBoxStatus(true);

					mPref.edit().putBoolean("auto_update", true).commit();

				}

			}
		});
	}

	/**
	 * 初始化归属地显示的方法
	 */
	public void initAddressView() {
		sivAddress = (SettingItemView) findViewById(R.id.siv_address);

		if (mPref.getBoolean("address", false)) {

			sivAddress.setCheckBoxStatus(true);
		} else {

			sivAddress.setCheckBoxStatus(false);
		}

		if (ServiceStatusUtils.isServiceRunning(SettingActivity.this,
				"com.l.mobliesafe.service.AddressService")) {

			sivAddress.setCheckBoxStatus(true);

		} else {

			sivAddress.setCheckBoxStatus(false);
		}

		sivAddress.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (sivAddress.isChecked()) {

					sivAddress.setCheckBoxStatus(false);

					mPref.edit().putBoolean("address", false).commit();

					stopService(new Intent(SettingActivity.this,
							AddressService.class));

				} else {

					sivAddress.setCheckBoxStatus(true);

					mPref.edit().putBoolean("address", true).commit();

					startService(new Intent(SettingActivity.this,
							AddressService.class));

				}

			}
		});
	}

	/**
	 * 初始化归属地显示的风格
	 */
	public void initAddressTheme() {

		final String[] items = { "蓝", "红" };
		scvToastAddress = (SettingClickView) findViewById(R.id.scv_toast_address);
		scvToastAddress.setTitle("归属地查询的风格");
		scvToastAddress.setDesc("活力城");
		int style = mPref.getInt("address_style", 0);
		if (style >= 0) {
			scvToastAddress.setDesc(items[style]);
		}

		scvToastAddress.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						SettingActivity.this);

				builder.setTitle("归属地显示框主题");
				// builder.setMessage("哈哈哈哈哈哈哈");

				builder.setSingleChoiceItems(items, 0,
						new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								mPref.edit().putInt("address_style", which)
										.commit();
								scvToastAddress.setDesc(items[which]);
								dialog.dismiss();
							}
						});
				builder.setNegativeButton("取消", null);
				builder.show();
			}
		});
	}

	/**
	 * 初始化归属地显示的位置
	 */
	public void initAddressLoacation() {
		scvAddressLocation = (SettingClickView) findViewById(R.id.scv_address_location);
		scvAddressLocation.setTitle("归属地显示框的位置");
		scvAddressLocation.setDesc("设置归属地显示框的位置");

		scvAddressLocation.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(SettingActivity.this,
						DragViewActivity.class));

			}
		});
	}
	
	
	public void initWatchDog(){
		
		 watch_dog = (SettingItemView) findViewById(R.id.siv_watch_dog);
		 
		 boolean runningProcess = SystemInfoUtils.isRunningProcess(SettingActivity.this,"com.l.mobliesafe.service.WatchDogService");
		 
//		 if(runningProcess){
//			 
//			 watch_dog.setCheckBoxStatus(true);
//			 
//		 }else{
//			 
//			 watch_dog.setCheckBoxStatus(false);
//			 
//		 }
		 
		 if(mPref.getBoolean("appSwicth",false)){
			 watch_dog.setCheckBoxStatus(true);
		 }else{
			 watch_dog.setCheckBoxStatus(false); 
		 }
		 watch_dog.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					if (watch_dog.isChecked()) {

						watch_dog.setCheckBoxStatus(false);
						mPref.edit().putBoolean("appSwicth",false).commit();
						
						stopService(new Intent(SettingActivity.this,WatchDogService.class));

					} else {
						
						watch_dog.setCheckBoxStatus(true);
						mPref.edit().putBoolean("appSwicth",true).commit();
						
						startService(new Intent(SettingActivity.this,WatchDogService.class));
						
					}

				}
			});
	}
}
