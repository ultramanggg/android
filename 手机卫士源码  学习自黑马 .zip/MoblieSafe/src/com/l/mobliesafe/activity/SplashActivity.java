package com.l.mobliesafe.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.LauncherActivity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.l.mobliesafe.R;
import com.l.mobliesafe.db.dao.AntivirusDao;
import com.l.mobliesafe.service.AddressService;
import com.l.mobliesafe.service.CallSafeService;
import com.l.mobliesafe.service.KillProcessService;
import com.l.mobliesafe.service.WatchDogService;
import com.l.mobliesafe.utils.StreamUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

public class SplashActivity extends Activity {

	protected static final int CODE_UPDATE_DIALOG = 0;

	protected static final int CODE_URL_ERROR = 1;

	protected static final int CODE_net_ERROR = 2;

	protected static final int CODE_JSON_ERROR = 3;

	protected static final int CODE_ENTER_HOME = 4;

	private TextView tvVersion;
	private TextView tvProgress;

	private String mVersionNmae;// 服务器传来的版本
	private int mVersionCode;// 服务器传来的
	private String mDesc;// 服务器传来的 描述信息
	private String mDownloadUrl;// 服务器传来的 下载地址

	private Handler mhanlder = new Handler() {

		public void handleMessage(android.os.Message msg) {
			
			switch (msg.what) {
			case CODE_UPDATE_DIALOG:

				showUpdateDialog();

				break;

			case CODE_URL_ERROR:

				Toast.makeText(SplashActivity.this, "服务器错误", Toast.LENGTH_SHORT)
						.show();
				enterHome();
				break;

			case CODE_net_ERROR:

				Toast.makeText(SplashActivity.this, "网络错误", Toast.LENGTH_SHORT)
						.show();
				enterHome();
				break;
			case CODE_JSON_ERROR:

				Toast.makeText(SplashActivity.this, "json错误",
						Toast.LENGTH_SHORT).show();
				enterHome();
				break;
			case CODE_ENTER_HOME:

				enterHome();

				break;

			default:

				break;
			}
		};
	};

	private SharedPreferences mPref;

	private RelativeLayout rl_root;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		
		tvVersion = (TextView) findViewById(R.id.tv_version);
		tvProgress = (TextView) findViewById(R.id.tv_progress);
		rl_root = (RelativeLayout) findViewById(R.id.rl_root);

		String versionName = getVersionName();

		tvVersion.setText("版本号：" + versionName);

		mPref = getSharedPreferences("config", MODE_PRIVATE);
		
		//是否开启自动杀死进程的服务
		if(mPref.getBoolean("killprocess",false)){
			
			startService(new Intent(SplashActivity.this, KillProcessService.class));
			
		}
		
		//开启设置中开启的服务
		startAddressListenService();
		startCallSafeService();
		startAppLock();
		
		createShortcut();
		
		boolean autoUpdate = mPref.getBoolean("auto_update", false);

		if (autoUpdate) {
			checkVersion();
		} else {
			mhanlder.sendEmptyMessageDelayed(CODE_ENTER_HOME, 2000);
		}
		
		//从assets文件夹拷贝数据库的方法
		copyDataBase("antivirus.db");
		copyDataBase("address.db");
		//更新病毒库
		//updateAntivirus();
		
		
		AlphaAnimation anim = new AlphaAnimation(0.3f, 1f);
		anim.setDuration(3000);
		rl_root.setAnimation(anim);
		// anim.start();
	}
	//更新病毒库
	private void updateAntivirus() {
		
		new Thread(){
			
			public void run() {
				
				HttpUtils httpUtils = new HttpUtils();
				httpUtils.send(HttpMethod.GET,"http://10.0.2.2:8080/vrius.json", new RequestCallBack<String>() {

					@Override
					public void onFailure(HttpException arg0, String arg1) {
						System.out.println("访问病毒服务器     失败");
					}

					@Override
					public void onSuccess(ResponseInfo<String> arg) {
						
						
						
						try {
							JSONObject jsonObject = new JSONObject(arg.result);
							
							String md5 = jsonObject.getString("md5");
							String desc = jsonObject.getString("desc");
							//System.out.println(md5+desc);
							AntivirusDao.addVirusInfo(md5, desc);
							
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
					}
				});
				
			};
			
		}.start();
	}

	/**
	 * 创建桌面的快捷方式
	 */
	private void createShortcut() {
		
		
		Intent intent=new Intent();
		
		intent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
		intent.putExtra("duplicate", false);
		Intent SIntent=new Intent();
		SIntent.setAction("aaa");
	
		
		intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "手机管家");
		intent.putExtra(Intent.EXTRA_SHORTCUT_ICON,BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher));
		intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT,SIntent);
		
		sendBroadcast(intent);
		
	}

	/**
	 * 获取当前版本的名字
	 * 
	 * @return String 当前版本的名字
	 */
	private String getVersionName() {
		PackageManager packageManger = getPackageManager();
		String versionName;
		try {
			PackageInfo packageInfo = packageManger.getPackageInfo(
					getPackageName(), 0);
			int versionCode = packageInfo.versionCode;

			versionName = packageInfo.versionName;

			//System.out.println(versionCode + ":" + versionName);

			return versionName;
		} catch (NameNotFoundException e) {
			// 没有包名会在这个异常中处理
			e.printStackTrace();
		}

		return "";
	}

	/**
	 * 获取本软件的当前的版本号
	 * 
	 * @return 当前的版本号 int
	 */
	private int getVersionCode() {
		PackageManager packageManger = getPackageManager();

		try {
			PackageInfo packageInfo = packageManger.getPackageInfo(
					getPackageName(), 0);
			int versionCode = packageInfo.versionCode;
			System.out.println("本地版本号：" + versionCode);

			return versionCode;
		} catch (NameNotFoundException e) {
			// 没有包名会在这个异常中处理
			e.printStackTrace();
		}

		return -1;
	}

	/**
	 * 从服务器获取版本信息
	 */
	private void checkVersion() {

		final long startTime = System.currentTimeMillis();

		new Thread() {

			private HttpURLConnection conn = null;

			public void run() {

				Message msg = Message.obtain();
				try {

					URL url = new URL("http://10.0.2.2:8080/update.json");

					conn = (HttpURLConnection) url.openConnection();

					conn.setRequestMethod("GET");// 必须大写
					conn.setReadTimeout(5000);
					conn.setReadTimeout(5000);
					conn.connect();

					int responseCode = conn.getResponseCode();

					System.out.println("网络状态：" + responseCode);

					if (responseCode == 200) {

						InputStream inputStream = conn.getInputStream();

						String readString = StreamUtils
								.readFormStream(inputStream);

						JSONObject jo = new JSONObject(readString);

						mVersionNmae = jo.getString("versionName");
						mVersionCode = jo.getInt("versionCode");
						mDesc = jo.getString("description");
						mDownloadUrl = jo.getString("downloadUrl1");

						if (mVersionCode > getVersionCode()) {
							// 半段是否需要更新
							// 需要弹出升级对话窗
							System.out.println("有更新");
							// showUpdateDialog();
							msg.what = CODE_UPDATE_DIALOG;

						} else {

							msg.what = CODE_ENTER_HOME;
						}
					}

				} catch (MalformedURLException e) {
					System.out.println("服务器错误");

					msg.what = CODE_URL_ERROR;

					e.printStackTrace();

				} catch (IOException e) {
					System.out.println("网络错误");
					msg.what = CODE_net_ERROR;

					e.printStackTrace();

				} catch (JSONException e) {
					System.out.println("json错误");
					msg.what = CODE_JSON_ERROR;

					e.printStackTrace();

				} finally {

					// 最后将消息交给hanlder处理
					long enterTime = System.currentTimeMillis();

					Long useTime = startTime - enterTime;

					if (useTime < 3000) {
						try {

							Thread.sleep(3000 - useTime);
							System.out
									.println("进入主页前的休眠时间：" + (3000 - useTime));
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						mhanlder.sendMessage(msg);
					}

					if (conn != null) {
						conn.disconnect();
					}
				}

			};
		}.start();

	}

	/**
	 * 弹出升级对话框的方法
	 */
	protected void showUpdateDialog() {

		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setTitle("最新版:" + mVersionNmae);
		builder.setMessage(mDesc);
		// builder.setCancelable(false);//使得返回键失效

		builder.setPositiveButton("更新", new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

				System.out.println("更新按钮被点击");

				download();
			}
		});

		builder.setNegativeButton("取消", new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

				System.out.println("取消按钮被点击");
				enterHome();

			}
		});
		// 设置返回键的监听 当点击返回键时跳回主界面
		builder.setOnCancelListener(new OnCancelListener() {

			@Override
			public void onCancel(DialogInterface dialog) {
				enterHome();

			}
		});

		builder.show();

	}

	/**
	 * 下载最新版本的apk文件
	 */
	protected void download() {

		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {

			tvProgress.setVisibility(View.VISIBLE);

			String target = Environment.getExternalStorageDirectory()
					+ "/update.apk";

			HttpUtils httpUtils = new HttpUtils();

			System.out.println(mDownloadUrl);
			System.out.println(target);
			httpUtils.download(mDownloadUrl, target,
					new RequestCallBack<File>() {

						@Override
						public void onLoading(long total, long current,
								boolean isUploading) {

							super.onLoading(total, current, isUploading);

							System.out.println("下载的进度为：" + current * 100
									/ total + "%");

							tvProgress.setText("下载的进度为：" + current * 100
									/ total + "%");
						}

						@Override
						public void onSuccess(ResponseInfo<File> arg0) {
							Toast.makeText(SplashActivity.this, "成功",
									Toast.LENGTH_SHORT).show();

							Intent intent = new Intent();

							intent.setAction(Intent.ACTION_VIEW);

							intent.addCategory(Intent.CATEGORY_DEFAULT);

							intent.setDataAndType(Uri.fromFile(arg0.result),
									"application/vnd.android.package-archive");

							// startActivity(intent);

							startActivityForResult(intent, 0);// 要求有结果的返回
						}

						@Override
						public void onFailure(HttpException arg0, String arg1) {
							Toast.makeText(SplashActivity.this, "失败",
									Toast.LENGTH_SHORT).show();

						}
					});

		} else {
			Toast.makeText(SplashActivity.this, "没有内存卡", Toast.LENGTH_SHORT)
					.show();
		}
	}

	/**
	 * 跳进主页
	 */
	private void enterHome() {
		Intent intent = new Intent(this, HomeActivity.class);
		startActivity(intent);
		finish();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		enterHome();
		super.onActivityResult(requestCode, resultCode, data);

	}

	/**
	 * 将数据库 移动到 files文件夹下的方法
	 */
	/**
	 * @param dbName数据库的名字
	 */
	private void copyDataBase(String dbName) {
		InputStream in = null;
		OutputStream out = null;
		File destFile = new File(getFilesDir(), dbName);
		
		//判断数据库是否存在，如果存在就直接跳出方法
		if(destFile.exists()){
			return;
		}
		
		try {
			
			out = new FileOutputStream(destFile);

			in = getAssets().open(dbName);

			int len = 0;
			byte[] buffer = new byte[1024];

			while ((len = in.read(buffer)) != -1) {

				out.write(buffer, 0, len);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				in.close();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public void startAddressListenService(){
		
		boolean address=mPref.getBoolean("address", false);
		
		System.out.println("来电显示的状态："+address);
		
		if(address){
			
			startService(new Intent(SplashActivity.this,AddressService.class));
		}
	}
	
	public void startCallSafeService(){
		boolean blackContacts=mPref.getBoolean("blackContacts", false);
		
		System.out.println("黑名单服务："+blackContacts);
		
		if(blackContacts){
			
			startService(new Intent(SplashActivity.this,CallSafeService.class));
		}
	}
	
	public void startAppLock(){
		
		 if(mPref.getBoolean("appSwicth",false)){
			 startService(new Intent(SplashActivity.this,WatchDogService.class)); 
		 }
		 
	}
}
