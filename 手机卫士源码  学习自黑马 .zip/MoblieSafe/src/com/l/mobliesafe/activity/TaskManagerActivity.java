package com.l.mobliesafe.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.l.mobliesafe.R;
import com.l.mobliesafe.bean.TaskInfo;
import com.l.mobliesafe.engine.TaskInfoParser;
import com.l.mobliesafe.utils.SystemInfoUtils;
import com.l.mobliesafe.utils.UIUtils;

public class TaskManagerActivity extends Activity {

	private TextView taskMemory;
	private TextView taskProcessCount;
	private ListView taskLV;
	boolean SHOW_SYSTEM_PROCESS=true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		sp = getSharedPreferences("config", Context.MODE_PRIVATE);

		initUI();
		initData();
	}
	
	
	@Override
	protected void onResume() {
		
		super.onResume();
		if(adapter!=null){
			adapter.notifyDataSetChanged();
		}
		
	}
	

	/**
	 * 初始化UI的方法
	 */
	private void initUI() {
		setContentView(R.layout.activity_task);
		taskProcessCount = (TextView) findViewById(R.id.tv_task_process_count);
		taskMemory = (TextView) findViewById(R.id.tv_task_memory);
		taskLV = (ListView) findViewById(R.id.task_lv);
		tab_task_type = (TextView) findViewById(R.id.tab_type);

		runningProcessCount = SystemInfoUtils
				.getRunningProcessCount(TaskManagerActivity.this);
		taskProcessCount.setText("进程：" + runningProcessCount + "个");
		totalMen = SystemInfoUtils.getTotalMen();
		availMem = SystemInfoUtils.getAvailMem(TaskManagerActivity.this);

		taskMemory.setText("剩余/总内存：" + availMem + "/" + totalMen);

		taskLV.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Object obj = taskLV.getItemAtPosition(position);

				if (obj != null && obj instanceof TaskInfo) {
					TaskInfo taskinfo = (TaskInfo) obj;

					CheckBox cb = (CheckBox) view
							.findViewById(R.id.task_select);
					
					if(taskinfo.getPackageName().equals(getPackageName())){
						taskinfo.setChecked(false);
					}else{
						
						if (taskinfo.isChecked()) {
							taskinfo.setChecked(false);
							cb.setChecked(false);
						} else {
							taskinfo.setChecked(true);
							cb.setChecked(true);
						}

						
					}

					
				}

			}
		});

	}

	/**
	 * 初始化页面数据
	 */

	private List<TaskInfo> taskInfos;
	private ArrayList<TaskInfo> userApp;
	private ArrayList<TaskInfo> systemApp;
	private TextView tab_task_type;
	MyTaskAdapter adapter;
	private String totalMen;
	private String availMem;
	private int runningProcessCount;
	private SharedPreferences sp;

	private void initData() {

		new Thread() {

			public void run() {

				taskInfos = TaskInfoParser
						.getTaskInfos(TaskManagerActivity.this);

				userApp = new ArrayList<TaskInfo>();

				systemApp = new ArrayList<TaskInfo>();

				for (TaskInfo taskInfo : taskInfos) {
					if (taskInfo.isUserApp()) {
						userApp.add(taskInfo);
					} else {
						systemApp.add(taskInfo);
					}

				}

				runOnUiThread(new Runnable() {

					@Override
					public void run() {

						adapter = new MyTaskAdapter();
						taskLV.setAdapter(adapter);

						taskLV.setOnScrollListener(new OnScrollListener() {

							@Override
							public void onScrollStateChanged(AbsListView view,
									int scrollState) {

							}

							@Override
							public void onScroll(AbsListView view,
									int firstVisibleItem, int visibleItemCount,
									int totalItemCount) {

								if (firstVisibleItem >= 0
										&& firstVisibleItem < userApp.size() + 1) {

									tab_task_type.setText("用户程序");

								} else {

									tab_task_type.setText("系统程序");

								}

							}
						});

					}
				});

			};
		}.start();

	}

	/**
	 * 作者： ug 时间： 2018-3-28 下午8:51:33 listview适配器
	 */
	public class MyTaskAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			
			if(sp.getBoolean("showSystemApp", true)){
				return userApp.size() + systemApp.size() + 2;
			}else{
				return userApp.size()+1;
			}
			
			
			
		}

		@Override
		public Object getItem(int position) {

			if (position == 0 || position == userApp.size() + 1) {

				return null;
			}

			if (position < userApp.size() + 1) {
				return userApp.get(position - 1);
			}

			else {

				return systemApp.get(position - userApp.size() - 2);
			}
			
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (position == 0) {

				TextView tab_type = new TextView(TaskManagerActivity.this);
				tab_type.setText("用户程序");
				tab_type.setTextColor(Color.BLACK);
				tab_type.setBackgroundColor(Color.CYAN);
				return tab_type;

			}

			if (position == userApp.size() + 1) {

				TextView tab_type = new TextView(TaskManagerActivity.this);
				tab_type.setText("系统程序");
				tab_type.setTextColor(Color.BLACK);
				tab_type.setBackgroundColor(Color.CYAN);
				return tab_type;

			}

			View v = null;

			if (convertView != null && convertView instanceof LinearLayout) {

				v = convertView;

			} else {

				v = View.inflate(TaskManagerActivity.this, R.layout.task_item,
						null);
			}

			ImageView icon = (ImageView) v.findViewById(R.id.task_icon);
			TextView name = (TextView) v.findViewById(R.id.task_name);
			TextView size = (TextView) v.findViewById(R.id.task_Size);
			TextView type = (TextView) v.findViewById(R.id.task_type);
			CheckBox check = (CheckBox) v.findViewById(R.id.task_select);

			if (position < userApp.size() + 1) {
				icon.setBackground(userApp.get(position - 1).getIcon());
				name.setText(userApp.get(position - 1).getAppName());
				size.setText(userApp.get(position - 1).getMemorysize() / 1024
						+ "MB");
				type.setText("用户");
				check.setChecked(userApp.get(position - 1).isChecked());
				
				if(userApp.get(position - 1).getPackageName().equals(getPackageName())){
					check.setVisibility(View.INVISIBLE);
				}else{
					check.setVisibility(View.VISIBLE);
				}
				
			} else {
				icon.setBackground(systemApp.get(
						position - userApp.size() - 1 - 1).getIcon());
				name.setText(systemApp.get(position - 1 - userApp.size() - 1)
						.getAppName());
				size.setText(systemApp.get(position - 1 - userApp.size() - 1)
						.getMemorysize() / 1024 + "MB");
				type.setText("系统");
				check.setChecked(systemApp.get(
						position - 1 - userApp.size() - 1).isChecked());
				
				if(!systemApp.get(position - 1 - userApp.size() - 1).getPackageName().equals(getPackageName())){				
					check.setVisibility(View.VISIBLE);
				}
			}

			return v;
		}

	}

	public void selectAll(View v) {
		for (TaskInfo ti : userApp) {
			
			if(ti.getPackageName().equals(getPackageName())){
				ti.setChecked(false);
				continue;
			}
			ti.setChecked(true);
		}
		for (TaskInfo ti : systemApp) {
			ti.setChecked(true);
		}

		adapter.notifyDataSetChanged();
	}

	public void selectInvert(View v) {

		for (TaskInfo ti : userApp) {
			
			if(ti.getPackageName().equals(getPackageName())){
				ti.setChecked(false);
				continue;
			}
			
			if (ti.isChecked()) {
				ti.setChecked(false);
			} else {
				ti.setChecked(true);
			}
		}
		for (TaskInfo ti : systemApp) {
			if (ti.isChecked()) {
				ti.setChecked(false);
			} else {
				ti.setChecked(true);
			}
		}

		adapter.notifyDataSetChanged();

	}

	public void taskClear(View v) {

		ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
		
		List<TaskInfo> tis = new ArrayList<TaskInfo>();
		
		int taskCount=0;
		
		for (TaskInfo  ti : userApp) {
			
			
			am.killBackgroundProcesses(ti.getPackageName());
			
			if(ti.isChecked()){
				tis.add(ti);
				taskCount++;
			}
		}
		
		for (TaskInfo  ti : systemApp) {
			
			am.killBackgroundProcesses(ti.getPackageName());
			
			if(ti.isChecked()){
				tis.add(ti);
				taskCount++;
			}
		}
		
		long killProcessMen=0;
		
		for (TaskInfo taskInfo : tis) {
			
			if(taskInfo.isUserApp()){
				userApp.remove(taskInfo);
			}else{
				systemApp.remove(taskInfo);
			}
			
			killProcessMen=killProcessMen+taskInfo.getMemorysize();
			
		}
		
		taskProcessCount.setText("进程："+(runningProcessCount-taskCount)+"个");
		 
		taskMemory.setText("剩余/总内存：" +(Integer.valueOf(availMem.split("MB")[0].trim())+killProcessMen/1024)+ "MB/" + totalMen);
		
		adapter.notifyDataSetChanged();
		
		
		UIUtils.showToast(TaskManagerActivity.this,"杀死了"+taskCount+"个应用，"+"共清理了"+killProcessMen/1024+"Mb的内存");
		
		
		 
		 
		
		
		

	}

	public void taskSet(View v) {
		
		
		Intent intent = new Intent(this,TaskSetActivity.class);
		
		startActivity(intent);
		
	}

	
}
