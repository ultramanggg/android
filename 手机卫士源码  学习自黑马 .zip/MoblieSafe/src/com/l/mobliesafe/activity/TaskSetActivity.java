package com.l.mobliesafe.activity;

import com.l.mobliesafe.R;
import com.l.mobliesafe.service.KillProcessService;
import com.l.mobliesafe.utils.SystemInfoUtils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

public class TaskSetActivity extends Activity {
	
	private CheckBox showSystemApp;
	private SharedPreferences sp;
	private CheckBox killService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_task_set);
		
		sp = getSharedPreferences("config", Context.MODE_PRIVATE);
		
		
		
		initUI();
	}

	private void initUI() {
		
		showSystemApp = (CheckBox) findViewById(R.id.task_set_showSystemApp);
		
		killService = (CheckBox) findViewById(R.id.task_set_KillService);
		
		boolean isrun=SystemInfoUtils.isRunningProcess(TaskSetActivity.this,"com.l.mobliesafe.service.KillProcessService");
		
		if(isrun){
			killService.setChecked(true);
		}else{
			killService.setChecked(false);
		}
		
		boolean ssApp = sp.getBoolean("showSystemApp", true);
		if(ssApp){
			showSystemApp.setChecked(true);
		}else{
			showSystemApp.setChecked(false);
		}
		
		
		
	}

	public void showSystemApp(View v){
		
		if(showSystemApp.isChecked()){
			
			showSystemApp.setChecked(false);
			sp.edit().putBoolean("showSystemApp",false).commit();
			
		}else{
			
			showSystemApp.setChecked(true);
			sp.edit().putBoolean("showSystemApp",true).commit();
		}
		
	}
	
	public void killprocess(View v){
		
	if(killService.isChecked()){
		
		killService.setChecked(false);
		sp.edit().putBoolean("killprocess",false);
		stopService(new Intent(TaskSetActivity.this,KillProcessService.class));
		
	}else{
		
		killService.setChecked(true);
		sp.edit().putBoolean("killprocess",true);
		
		startService(new Intent(TaskSetActivity.this,KillProcessService.class));
	}	
	
		
	}
}
