package com.l.mobliesafe.activity;

import java.util.List;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.TrafficStats;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.l.mobliesafe.R;
import com.l.mobliesafe.bean.AppInfo;
import com.l.mobliesafe.engine.AppInfos;

public class TrafficActivity extends Activity {
	
	private ListView lv;
	private List<AppInfo> appInfos;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_traffic);
		
		
		init();
		initData();
	}

	private void initData() {
		
		
		appInfos = AppInfos.getAppInfos(TrafficActivity.this);
		
		
		
		
		Myadater myadater = new Myadater();
		lv.setAdapter(myadater);
	}

	private void init() {
		lv = (ListView) findViewById(R.id.traffic_lv);
	}
	
	class Myadater extends BaseAdapter{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return appInfos.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			
			View v = null;
			if(convertView==null){
				
				v=View.inflate(TrafficActivity.this,R.layout.traffic_item,null);
				
			}else{
				v=convertView;
			}
			
			ImageView icon=(ImageView) v.findViewById(R.id.traffic_app_icon);
			TextView appName=(TextView) v.findViewById(R.id.traffic_app_name);
			TextView rx=(TextView) v.findViewById(R.id.up_liuliang);
			TextView tx=(TextView) v.findViewById(R.id.down_liuliang);
			
			icon.setImageDrawable(appInfos.get(position).getIcon());
			appName.setText(appInfos.get(position).getAppName());
			
			rx.setText(appInfos.get(position).getAppRx());
			tx.setText(appInfos.get(position).getAppTx());
			return v;
		}
		
	}

}
