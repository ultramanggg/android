package com.l.mobliesafe.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public abstract class MyBaseAdaper<T> extends BaseAdapter {

	protected List<T> mlist=null;
	protected Context mcontext=null;
	
	private MyBaseAdaper() {
		
	}
	
	public MyBaseAdaper(List<T> list,Context context) {
		
		this.mlist=list;
		this.mcontext=context;
	}
	@Override
	public int getCount() {

		return mlist.size();
	}

	@Override
	public Object getItem(int position) {
		
		return mlist.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

}
