package com.l.mobliesafe.admin;

import android.app.admin.DeviceAdminReceiver;

public class AdnimReceiver extends DeviceAdminReceiver {

}
