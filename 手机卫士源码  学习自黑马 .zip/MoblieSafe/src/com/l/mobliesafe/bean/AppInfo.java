package com.l.mobliesafe.bean;

import android.R.drawable;
import android.graphics.drawable.Drawable;

/**
 * 
 * 包含应用信息的累
 * @author ug
 *
 */
public class AppInfo {

	/**
	 * 应用图标
	 */
	private Drawable icon;
	/**
	 * 应用名称
	 */
	private String appName;
	/**
	 * 应用大小
	 */
	private long appSize;
	/**
	 * 是不是用户APP
	 */
	public boolean userApp;

	private boolean isRom;
	
	private String apkPackageName;
	
	private String appRx="0";
	private String appTx="0";
	
	
	
	public String getAppRx() {
		return appRx;
	}

	public void setAppRx(String appRx) {
		this.appRx = appRx;
	}

	public String getAppTx() {
		return appTx;
	}

	public void setAppTx(String appTx) {
		this.appTx = appTx;
	}

	public String getApkPackageName() {
		return apkPackageName;
	}

	public void setApkPackageName(String apkPackageName) {
		this.apkPackageName = apkPackageName;
	}

	public boolean isRom() {
		return isRom;
	}

	public void setRom(boolean isRom) {
		this.isRom = isRom;
	}

	public Drawable getIcon() {
		return icon;
	}

	public void setIcon(Drawable icon) {
		this.icon = icon;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public long getAppSize() {
		return appSize;
	}

	public void setAppSize(long appSize) {
		this.appSize = appSize;
	}

	public boolean isUserApp() {
		return userApp;
	}

	public void setUserApp(boolean userApp) {
		this.userApp = userApp;
	}

	@Override
	public String toString() {
		return "AppInfo [icon=" + icon + ", appName=" + appName + ", appSize="
				+ appSize + ", ********用户应用=" + userApp + "*********, isRom=" + isRom + "]\n";
	}

	
	
	
}
