package com.l.mobliesafe.bean;

import android.graphics.drawable.Drawable;

import com.l.mobliesafe.R.drawable;

public class TaskInfo {
	
	private Drawable icon;
	private String packageName;
	private String appName;
	private long memorysize;
	private boolean userApp;
	
	private boolean isChecked=false;
	
	

	
	
	public boolean isChecked() {
		return isChecked;
	}
	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}
	
	
	public Drawable getIcon() {
		return icon;
	}
	public void setIcon(Drawable icon2) {
		this.icon = icon2;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public long getMemorysize() {
		return memorysize;
	}
	public void setMemorysize(long memorysize) {
		this.memorysize = memorysize;
	}
	public boolean isUserApp() {
		return userApp;
	}
	public void setUserApp(boolean userApp) {
		this.userApp = userApp;
	}
	@Override
	public String toString() {
		return "TaskInfo [icon=" + icon + ", packageName=" + packageName
				+ ", appName=" + appName + ", memorysize=" + memorysize
				+ ", userApp=" + userApp + "]";
	}
	
	

}
