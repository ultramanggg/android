package com.l.mobliesafe.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * 归属地查询 工具累
 * 
 * @author huawe p7
 * 
 */
public class AddressDao {

	private static final String path = "/data/data/com.l.mobliesafe/files/address.db";

	// 数据库必须是这个路径，否则无法访问
	// 需要将数据库导入该路径
	public static String getAddress(String phoneNumber) {
		String phoneAddress = "未知号码";

		SQLiteDatabase database = SQLiteDatabase.openDatabase(path, null,
				SQLiteDatabase.OPEN_READONLY);
		//^1[3-8]\d{9}$正则表达式匹配
		
		if(phoneNumber.matches("^1[3-8]\\d{9}$")){
			Cursor cusor= database.rawQuery(
					"select location from data2 where id=(select outkey from data1 where id=?)",
					new String[] {phoneNumber.substring(0, 7)});
			
			if(cusor.moveToNext()){
				phoneAddress=cusor.getString(0);
			}else{
				phoneAddress="未知号码";
			}
			
			cusor.close();
		}
		database.close();
		

		return phoneAddress;

	}
}
