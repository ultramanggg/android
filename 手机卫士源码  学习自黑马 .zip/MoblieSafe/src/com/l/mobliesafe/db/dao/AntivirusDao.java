package com.l.mobliesafe.db.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class AntivirusDao {
	
	private static final String path = "/data/data/com.l.mobliesafe/files/antivirus.db";
	
	public static String scanVitus(String appMD5){
		
		SQLiteDatabase database = SQLiteDatabase.openDatabase(path, null,
				SQLiteDatabase.OPEN_READONLY);
		
		Cursor cursor = database.rawQuery("select desc from datable where md5 = ?",new String[]{appMD5});
		
		
		if(cursor.moveToNext()){
			
			String desc = cursor.getString(0);
			
			cursor.close();
			
			return desc;
		}
		return null;
	}
	
	
	public static void addVirusInfo(String md5,String desc){
		
			
			SQLiteDatabase database = SQLiteDatabase.openDatabase(path, null,
					SQLiteDatabase.OPEN_READWRITE);
			
			ContentValues values = new ContentValues();
			

			values.put("md5", md5);
			
			values.put("type", 6);
			
			values.put("name", "应用的包名字");
			
			values.put("desc", desc);
			
			database.insert("datable", null,values);
			
			database.close();
		
	}
}
