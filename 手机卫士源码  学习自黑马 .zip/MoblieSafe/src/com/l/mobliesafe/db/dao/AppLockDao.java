package com.l.mobliesafe.db.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class AppLockDao {

	private AppLockOpenHelper openHelper;

	public AppLockDao(Context context) {

		openHelper = new AppLockOpenHelper(context);
	}

	public void insert(String packageName,boolean islock) {
		SQLiteDatabase db = openHelper.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put("packageName", packageName);
		values.put("islock", islock);
		db.insert("applock",null, values);
		db.close();

	}

	public void delete(String packageName) {
		SQLiteDatabase db = openHelper.getWritableDatabase();

		db.delete("applock","packageName = ?",new String[]{packageName});
		db.close();
	}

	public boolean find(String packageName) {
		
		SQLiteDatabase db = openHelper.getReadableDatabase();
		
		Cursor cursor = db.query("applock", null,"packageName=?", new String[]{packageName}, null, null, null);
		
		if(cursor.moveToNext()){
			cursor.close();
			db.close();
			return true;
		}else{
			cursor.close();
			db.close();
			return false;
		}
	}
	
	public void setLockState(String packageName,boolean islock){
		
		SQLiteDatabase db = openHelper.getWritableDatabase();
		
		//db.delete("applock","packageName = ?",new String[]{packageName});
		
		ContentValues contentValues = new ContentValues();
		contentValues.put("islock",islock);
		db.update("applock",contentValues,"packageName = ?",new String[]{packageName});
		db.close();
	}
	
	public boolean islock(String packageName){
		
		SQLiteDatabase db = openHelper.getReadableDatabase();
		
		Cursor cursor = db.query("applock",new String[]{"packageName","islock"},"packageName=?", new String[]{packageName}, null, null, null);
		if(cursor.moveToNext()){
			String columnName = cursor.getString(0);
			String int1 = cursor.getString(1);
			
			if(int1.equals("0")){
				return false;
			}else{
				return true;
			}
		}
		return false;
		
	}
	
}
