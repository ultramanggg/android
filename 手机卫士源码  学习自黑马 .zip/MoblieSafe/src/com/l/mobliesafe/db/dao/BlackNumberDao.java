package com.l.mobliesafe.db.dao;

import java.util.ArrayList;
import java.util.List;

import com.l.mobliesafe.bean.BlackNumberInfo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.SystemClock;

/**
 * @author huawe p7
 * 
 */
public class BlackNumberDao {

	private BlackNumberOpenHelper helper;

	public BlackNumberDao(Context context) {

		helper = new BlackNumberOpenHelper(context);

	}

	/**
	 * 添加一个号码到黑名单
	 * 
	 * @param number
	 *            拦截的电话号码
	 * @param mode
	 *            拦截的模式
	 */
	public boolean addBlackNum(String number, String mode) {

		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("number", number);
		contentValues.put("mode", mode);
		long rowId = db.insert("blacknumber", null, contentValues);
		if (rowId == -1) {
			return false;
		}

		return true;

	}

	/**
	 * 根据电话号删除黑名单号码
	 * 
	 * @param number
	 *            要删除的电话号码
	 * @return 是否成功
	 */
	public boolean deleteBlackNum(String number) {

		SQLiteDatabase db = helper.getWritableDatabase();
		int line = db
				.delete("blacknumber", "number=?", new String[] { number });
		if (line == 0) {
			return false;
		}
		return true;

	}

	/**
	 * 根据电话号码修改拦截的模式
	 * 
	 * @param number
	 *            修改模式的电话号码
	 * @return 是否成功修改
	 */
	public boolean changeNumMode(String number, String mode) {

		SQLiteDatabase db = helper.getWritableDatabase();

		ContentValues contentValues = new ContentValues();
		contentValues.put("mode", mode);
		int line = db.update("blacknumber", contentValues, "number=?",
				new String[] { number });
		if (line == 0) {
			return false;
		}
		return true;

	}

	/**
	 * 根据电话号码查找
	 * 
	 * @param number
	 *            查找的电话号码
	 * @return 电话的拦截模式
	 */
	public String findByNum(String number) {

		String mode = "";

		SQLiteDatabase db = helper.getReadableDatabase();

		Cursor cursor = db.query("blacknumber", new String[] { "mode" },
				"number=?", new String[] { number }, null, null, null);
		if (cursor.moveToNext()) {
			mode = cursor.getString(0);
		}
		cursor.close();
		db.close();
		return mode;

	}

	public List<BlackNumberInfo> findAll() {

		BlackNumberInfo bi = null;
		List<BlackNumberInfo> bis = new ArrayList<BlackNumberInfo>();
		;
		SQLiteDatabase db = helper.getReadableDatabase();
		Cursor cursor = db
				.query("blacknumber", new String[] { "number", "mode" }, null,
						null, null, null, null);
		while (cursor.moveToNext()) {

			bi = new BlackNumberInfo();
			bi.setNumber(cursor.getString(0));
			bi.setMode(cursor.getString(1));
			bis.add(bi);
		}
		cursor.close();
		db.close();

		SystemClock.sleep(3000);
		return bis;

	}

	/**
	 * 根据页面信息大小和页数查询
	 * @param pageNumber  查询的是第几页
	 * @param pageSize		每页的信息数量
	 * @return	包含一页信息的 list；
	 */
	public List<BlackNumberInfo> findPage(int pageNumber, int pageSize) {
		
		List<BlackNumberInfo> nums=new ArrayList<BlackNumberInfo>();
		
		SQLiteDatabase db = helper.getReadableDatabase();
		
		
		Cursor cursor = db.rawQuery(
				"select mode,number from blacknumber limit ? offset ?",
				new String[] { String.valueOf(pageSize),
						String.valueOf(pageNumber * pageSize) });
		
		while(cursor.moveToNext()){
			BlackNumberInfo bi=new BlackNumberInfo();
			
			bi.setMode(cursor.getString(0));
			bi.setNumber(cursor.getString(1));
			
			nums.add(bi);
			
		}
		cursor.close();
		db.close();
		return nums;

	}
	
	/**
	 * 统计数据库中数据的数量
	 * @return  数据库中总共有多少条 数据
	 */
	public int getTotalNumber(){
		SQLiteDatabase db = helper.getReadableDatabase();
		Cursor cursor = db.rawQuery("select count(*) from blacknumber", null);
		cursor.moveToNext();
		int count = cursor.getInt(0);
		
		cursor.close();
		db.close();
		return count;
		
	}
}
