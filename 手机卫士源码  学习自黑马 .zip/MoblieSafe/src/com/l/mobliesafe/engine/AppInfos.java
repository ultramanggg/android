package com.l.mobliesafe.engine;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.l.mobliesafe.bean.AppInfo;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.TrafficStats;
import android.text.format.Formatter;

public class AppInfos {

	public static List<AppInfo> getAppInfos(Context context) {
		//获取包的管理对象
		PackageManager packageManager = context.getPackageManager();
		//通过包管理拿到所有的已经安装的应用的信息
		List<PackageInfo> apps = packageManager.getInstalledPackages(0);
		
		List<AppInfo> appInfos=new ArrayList<AppInfo>();
		
		for (PackageInfo packageInfo : apps) {
			
			AppInfo appInfo = new AppInfo();
			//------------------------------------------------------------------
			//通过包或得app的信息，然后或得名称和图标
			Drawable appIcon = packageInfo.applicationInfo.loadIcon(packageManager);
			String appName = packageInfo.applicationInfo.loadLabel(packageManager).toString();
			
			String packageName = packageInfo.packageName;
			
			
			//获取app资源的路径,然后将路径转换为文件对象，通过文件对象获取大小
			String sourceDir = packageInfo.applicationInfo.sourceDir;
			File file=new File(sourceDir);
			long AppSize_byte = file.length();
			//获取app的类型
			int flags = packageInfo.applicationInfo.flags;
		
		
			
			if((flags & ApplicationInfo.FLAG_SYSTEM) !=0)
			{
				appInfo.setUserApp(false);
			}else{
				appInfo.setUserApp(true);
			}
			
			if((flags & ApplicationInfo.FLAG_EXTERNAL_STORAGE)!=0)
			{
				appInfo.setRom(false);
			}else{
				appInfo.setRom(true);
			}
			
			int uid = packageInfo.applicationInfo.uid;
			
			long uidRxBytes = TrafficStats.getUidRxBytes(uid);
			long uidTxBytes = TrafficStats.getUidTxBytes(uid);
			
		
			
			//------------------------------------------------------------------	
			//将信息加入bean，把bean装入list；
			appInfo.setAppName(appName);
			appInfo.setIcon(appIcon);
			appInfo.setAppSize(AppSize_byte);
			appInfo.setApkPackageName(packageName);
			
			appInfo.setAppRx(Formatter.formatFileSize(context, uidRxBytes));
			appInfo.setAppTx(Formatter.formatFileSize(context, uidTxBytes));
			//------------------------------------------------
			appInfos.add(appInfo);
			
		}
		return appInfos;
	}

	private AppInfos() {

	}

}
