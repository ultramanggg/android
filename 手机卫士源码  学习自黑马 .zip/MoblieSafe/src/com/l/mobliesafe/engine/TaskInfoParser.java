package com.l.mobliesafe.engine;

import java.util.ArrayList;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;
import android.os.Debug.MemoryInfo;

import com.l.mobliesafe.R;
import com.l.mobliesafe.bean.TaskInfo;

public class TaskInfoParser {
	
	
	public static List<TaskInfo> getTaskInfos(Context context){
		
		PackageManager packageManager = context.getPackageManager();
		
		ActivityManager am=(ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		
			List<RunningAppProcessInfo> AppProcesses = am.getRunningAppProcesses();
			
			
			ArrayList<TaskInfo> taskInfoS = new ArrayList<TaskInfo>();
			
			for (RunningAppProcessInfo runningAppProcessInfo : AppProcesses) {
				
				String processName = runningAppProcessInfo.processName;
				
				TaskInfo taskInfo = new TaskInfo();
				
				try {
					int[] pids =new int[]{runningAppProcessInfo.pid};
					MemoryInfo[] memoryInfo = am.getProcessMemoryInfo(pids);
					int totalPrivateDirty = memoryInfo[0].getTotalPrivateDirty();
					
					
					PackageInfo packageInfo = packageManager.getPackageInfo(processName, 0);
					
					Drawable icon = packageInfo.applicationInfo.loadIcon(packageManager);
					String appName = packageInfo.applicationInfo.loadLabel(packageManager).toString();
					
					String sourceDir = packageInfo.applicationInfo.sourceDir;
					
					if(sourceDir.startsWith("/data/")){
						
						taskInfo.setUserApp(true);
						
					}else {
						
						taskInfo.setUserApp(false);
						
					}
					
					taskInfo.setMemorysize(totalPrivateDirty);
					taskInfo.setAppName(appName);
					taskInfo.setIcon(icon);
					taskInfo.setPackageName(processName);
					taskInfoS.add(taskInfo);
				
				} catch (Exception e) {
					
					taskInfo.setAppName(processName);
					taskInfo.setIcon(context.getResources().getDrawable(R.drawable.icon5));
					e.printStackTrace();
				}
				
			}
		return taskInfoS;
	}

}
