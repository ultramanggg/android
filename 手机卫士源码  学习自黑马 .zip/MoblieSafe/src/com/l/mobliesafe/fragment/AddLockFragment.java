package com.l.mobliesafe.fragment;

import java.util.ArrayList;
import java.util.List;

import com.l.mobliesafe.R;
import com.l.mobliesafe.activity.AppLockActivity;
import com.l.mobliesafe.bean.AppInfo;
import com.l.mobliesafe.bean.TaskInfo;
import com.l.mobliesafe.db.dao.AppLockDao;
import com.l.mobliesafe.engine.AppInfos;
import com.l.mobliesafe.engine.TaskInfoParser;
import com.l.mobliesafe.utils.SystemInfoUtils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class AddLockFragment extends Fragment {
	
	
	private List<AppInfo> appInfos;
	private View v;
	private List<AppInfo> unlockApp;
	private MyAdapter adapter;
	private AppLockDao appLockDao;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		v = inflater.inflate(R.layout.fragment_add_lock,null);
	
		
		return v;
		
		
	}
	
	@Override
	public void onStart() {
		
		super.onStart();
		
		
		
		TextView title=(TextView) v.findViewById(R.id.add_applock_title);
		ListView lv=(ListView) v.findViewById(R.id.add_applock_lv);
		
		appInfos = AppInfos.getAppInfos(getActivity());
		
		unlockApp = new ArrayList<AppInfo>();
		appLockDao = new AppLockDao(getActivity());
		
		for (AppInfo appInfo : appInfos) {
			
			
			
			
			if(appLockDao.find(appInfo.getApkPackageName())){
				
				
			}else{
				unlockApp.add(appInfo);
			}
		}
		
		
		
		
		
		adapter = new MyAdapter();
		
		lv.setAdapter(adapter);
		
	}
	
	
	
	class MyAdapter extends BaseAdapter{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return unlockApp.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView( final int position, View convertView, ViewGroup parent) {
			
			
			TextView textView = new TextView(getActivity());
			
			Handler handler = null;
			final View v1;
			
			
			
			if(convertView==null){
				
				v1=View.inflate(getActivity(),R.layout.lock_left,null);
				
				handler=new Handler();
				handler.icon=(ImageView) v1.findViewById(R.id.left_lock_appicon);
				handler.appname=(TextView) v1.findViewById(R.id.left_lock_appName);
				handler.lock=(ImageView) v1.findViewById(R.id.left_lock_lock);
				
				v1.setTag(handler);
				
				
			}else{
				
				v1=convertView;
			}
			
			
			handler=(Handler) v1.getTag();
			
			handler.lock.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					
				TranslateAnimation t=new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF,1f, 
						TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF,0);
					t.setDuration(500);
					v1.startAnimation(t);
					
					new Thread(){
						
						
						public void run() {
							
							SystemClock.sleep(500);
						
							getActivity().runOnUiThread(new Runnable() {
								
								@Override
								public void run() {
									appLockDao.insert(unlockApp.get(position).getApkPackageName(),true);
									
									unlockApp.remove(position);
									
									adapter.notifyDataSetChanged();
								}
							});
							
							
							
						};
					}.start();
					
					
				}
			});
			
			handler.icon.setImageDrawable(unlockApp.get(position).getIcon());
			handler.appname.setText(unlockApp.get(position).getAppName());
			
			return v1;
		}
		
	}
	
	static class Handler{
		ImageView icon;
		TextView  appname;
		ImageView lock;
	}

}
