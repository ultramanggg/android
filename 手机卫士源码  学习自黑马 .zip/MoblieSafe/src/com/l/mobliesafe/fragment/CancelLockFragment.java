package com.l.mobliesafe.fragment;

import java.util.ArrayList;
import java.util.List;

import com.l.mobliesafe.R;
import com.l.mobliesafe.bean.AppInfo;
import com.l.mobliesafe.db.dao.AppLockDao;
import com.l.mobliesafe.engine.AppInfos;
import com.l.mobliesafe.fragment.AddLockFragment.Handler;
import com.l.mobliesafe.fragment.AddLockFragment.MyAdapter;

import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class CancelLockFragment extends Fragment {
	
	private List<AppInfo> appInfos;
	private View v;
	private List<AppInfo> lockApp;
	private MyAdapter adapter;
	private AppLockDao appLockDao;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		v=inflater.inflate(R.layout.fragment_cancel_lock, null, false);
		return v;

	}

	

	public void onStart() {

		super.onStart();

		TextView title = (TextView) v.findViewById(R.id.cancel_lock_title);
		ListView lv = (ListView) v.findViewById(R.id.cancel_lock_lv);

		appInfos = AppInfos.getAppInfos(getActivity());

		lockApp = new ArrayList<AppInfo>();
		appLockDao = new AppLockDao(getActivity());

		for (AppInfo appInfo : appInfos) {

			if (appLockDao.find(appInfo.getApkPackageName())) {
				lockApp.add(appInfo);
			} else {
				
			}
		}

		adapter = new MyAdapter();

		lv.setAdapter(adapter);

	}

	class MyAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return lockApp.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			TextView textView = new TextView(getActivity());

			Handler handler = null;
			final View v1;

			if (convertView == null) {

				v1 = View.inflate(getActivity(), R.layout.lock_right, null);

				handler = new Handler();
				handler.icon = (ImageView) v1
						.findViewById(R.id.rignt_lock_icon);
				handler.appname = (TextView) v1
						.findViewById(R.id.right_lock_name);
				handler.lock = (ImageView) v1.findViewById(R.id.right_lock_unlock);

				v1.setTag(handler);

			} else {

				v1 = convertView;
			}

			handler = (Handler) v1.getTag();
			handler.lock.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					
					
					TranslateAnimation t=new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF,-1f, 
							TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF,0);
						t.setDuration(500);
						v1.startAnimation(t);
						
						new Thread(){
							
							
							public void run() {
								
								SystemClock.sleep(500);
							
								getActivity().runOnUiThread(new Runnable() {
									
									@Override
									public void run() {
										appLockDao.delete(lockApp.get(position)
												.getApkPackageName());

										lockApp.remove(position);

										adapter.notifyDataSetChanged();
									}
								});
								
								
								
							};
						}.start();

				}
			});

			handler.icon.setImageDrawable(lockApp.get(position).getIcon());
			handler.appname.setText(lockApp.get(position).getAppName());

			return v1;
		}

	}

	static class Handler {
		ImageView icon;
		TextView appname;
		ImageView lock;
	}

}
