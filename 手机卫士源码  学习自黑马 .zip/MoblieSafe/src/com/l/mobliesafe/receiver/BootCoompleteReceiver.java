package com.l.mobliesafe.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.TelephonyManager;
import android.telephony.gsm.SmsManager;

/**
 * 本广播用于检测手机的重启与开机
 * 
 * @author huawe p7
 * 
 */
public class BootCoompleteReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {

		// 获取sp的方法为context的内置方法，当前是在 Beceiver当中，所以需要从context中获取。
		SharedPreferences sp = context.getSharedPreferences("config",context.MODE_PRIVATE);
		//判断防盗保护是否开启
		if (sp.getBoolean("safe", true)) {
			
			String sim = sp.getString("sim", "");

			if (!"".equals(sim)) {
				TelephonyManager tm = (TelephonyManager) context
						.getSystemService(context.TELEPHONY_SERVICE);
				String curruntSim = tm.getSimSerialNumber()+"123";
				if (sim.equals(curruntSim)) {
					System.out.println("手机安全");
				} else {
					System.out.println("手机危险");
					String pNum=sp.getString("safePhone","");
					System.out.println(pNum);
					SmsManager smsManger= SmsManager.getDefault();
					smsManger.sendTextMessage(pNum, null,"sim scard changed !", null, null);
				}
			}
		}
	}

}
