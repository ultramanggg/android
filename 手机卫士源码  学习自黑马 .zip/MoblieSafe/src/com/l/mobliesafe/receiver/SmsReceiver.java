package com.l.mobliesafe.receiver;


import com.l.mobliesafe.R;
import com.l.mobliesafe.service.LocationService;

import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.sax.StartElementListener;
import android.telephony.gsm.SmsMessage;


public class SmsReceiver extends BroadcastReceiver {

	private SharedPreferences mPref;
	
	//设备管理器引用
	 private DevicePolicyManager mdPM;
	 private ComponentName mDeviceAdminSample;
	@Override
	public void onReceive(Context context, Intent intent) {
		
		mPref = context.getSharedPreferences("config", context.MODE_PRIVATE);
		
		
		  //系统分配的设备 管理服务引用事例
	     mdPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
		 //本应用设备管理处理类的 实例，系统根据此类识别到这个应用
		 mDeviceAdminSample = new ComponentName(context, com.l.mobliesafe.admin.AdnimReceiver.class);
	        
	     
		
		Object[] objects = (Object[]) intent.getExtras().get("pdus");
		
		for(Object obj : objects){
			
			SmsMessage smsMessage=android.telephony.gsm.SmsMessage.createFromPdu( (byte[]) obj);
			
			String smsAddress = smsMessage.getOriginatingAddress();
			String smsBody = smsMessage.getDisplayMessageBody();
			
			System.out.println(smsAddress+smsBody);
			
			if("520".equals(smsBody)){
				MediaPlayer mp = MediaPlayer.create(context, R.raw.alarm);
				
				mp.setVolume(1f, 1f);
				mp.setLooping(true);
				mp.start();
				
				abortBroadcast();
			}else if("521".equals(smsBody)){
				
				context.startService(new Intent(context,LocationService.class));
				
				String location=mPref.getString("location", "");
				
				System.out.println(location+"位置");
				
				abortBroadcast();
			}else if("123".equals(smsBody)){
				
			}else if("564".equals(smsBody)){
				
				mdPM.lockNow();
    			
    			mdPM.resetPassword("", 0);
    			abortBroadcast();
				
			}
		}

	}

}
