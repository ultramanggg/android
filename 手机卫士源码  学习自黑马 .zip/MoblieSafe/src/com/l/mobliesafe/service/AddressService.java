package com.l.mobliesafe.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.TextView;

import com.l.mobliesafe.R;
import com.l.mobliesafe.db.dao.AddressDao;

public class AddressService extends Service {

	private TelephonyManager tm;
	private MyListener listener;
	private OutCallReceiver outCallReceiver;
	private WindowManager mWM;
	private View view;
	private SharedPreferences mPref;
	private WindowManager.LayoutParams params;
	private int width;
	private int height;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {

		super.onCreate();
		mPref = getSharedPreferences("config", MODE_PRIVATE);
		tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		listener = new MyListener();
		tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
		outCallReceiver = new OutCallReceiver();
		IntentFilter filter = new IntentFilter(Intent.ACTION_NEW_OUTGOING_CALL);
		registerReceiver(outCallReceiver, filter);
	}

	class MyListener extends PhoneStateListener {

		@Override
		public void onCallStateChanged(int state, String incomingNumber) {

			switch (state) {

			case TelephonyManager.CALL_STATE_RINGING:

				String address = AddressDao.getAddress(incomingNumber);

				showToast(address);

				break;

			case TelephonyManager.CALL_STATE_IDLE:
				if (mWM != null) {
					mWM.removeView(view);
					view = null;
				}
				break;

			default:
				break;

			}

			super.onCallStateChanged(state, incomingNumber);

		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		// 通知控制器停止来电的监听
		tm.listen(listener, PhoneStateListener.LISTEN_NONE);

		unregisterReceiver(outCallReceiver);

	}

	// 去电监听的广播接收者

	class OutCallReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			String number = getResultData();// 获取去点的电话号码

			String address = AddressDao.getAddress(number);

			// Toast.makeText(context, address, Toast.LENGTH_LONG).show();

			showToast(address);
		}

	}

	/**
	 * 自定义浮窗口
	 */
	private void showToast(String text) {

		int addressStyle = mPref.getInt("address_style", 0);

		int[] style = { R.drawable.toast_address, R.drawable.toast_address1 };

		mWM = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
		
		width = mWM.getDefaultDisplay().getWidth();
		height = mWM.getDefaultDisplay().getHeight();
		
		params = new WindowManager.LayoutParams();

		// 设置插入窗口的控件的布局参数
		params.width = WindowManager.LayoutParams.WRAP_CONTENT;
		params.height = WindowManager.LayoutParams.WRAP_CONTENT;
		params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
				| WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
		// | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE 不能触摸
		params.format = PixelFormat.TRANSLUCENT;

		// 设置布局的类型 需要system.alert.windows权限
		params.type = WindowManager.LayoutParams.TYPE_PHONE;

		// 将参考坐标原点由中心点设置为左上角
		params.gravity = Gravity.LEFT + Gravity.TOP;

		params.setTitle("Toast");

		// 设置插入控件的位置
		params.x = mPref.getInt("l", 0);
		params.y = mPref.getInt("t", 0);

		view = View.inflate(this, R.layout.toast_address, null);

		view.setBackgroundResource(style[addressStyle]);
		
		

		TextView tvView = (TextView) view.findViewById(R.id.toast_address);
		tvView.setText(text);

		tvView.setTextColor(Color.GREEN);

		// 为插入窗口的控件 设置触摸事件
		view.setOnTouchListener(new OnTouchListener() {
			
			private int startX;
			private int stratY;
			private int dx;
			private int dy;

			@Override
			public boolean onTouch(View v, MotionEvent event) {

				switch (event.getAction()) {
				
				case MotionEvent.ACTION_DOWN:
					startX = (int) event.getRawX();
					stratY = (int) event.getRawY();


					break;
				case MotionEvent.ACTION_MOVE:
					
					int endX = (int) event.getRawX();
					int endY = (int) event.getRawY();

					dx = endX - startX;
					dy = endY - stratY;
					
					
					params.x+=dx;
					params.y+=dy;
					if(params.x<0){
						params.x=0;
					}
					if(params.y<0){
						params.y=0;
					}
					if(params.x>width){
						params.x=width;
					}
					if(params.y>height){
						params.y=height;
					}
					mWM.updateViewLayout(view, params);
					
					startX = (int) event.getRawX();
					stratY = (int) event.getRawY();

					break;
				case MotionEvent.ACTION_UP:
					
					mPref.edit().putInt("l",params.x).commit();
					mPref.edit().putInt("t",params.y).commit();
					
					break;

				default:
					break;
				}
				return true;// 拦截事件的广播开启
			}
		});

		// 给窗口添加要显示的内容和显示的参数
		mWM.addView(view, params);
	}
}
