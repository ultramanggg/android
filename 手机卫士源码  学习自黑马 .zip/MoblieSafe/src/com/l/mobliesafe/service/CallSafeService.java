package com.l.mobliesafe.service;

import java.lang.reflect.Method;
import java.net.URI;

import com.android.internal.telephony.ITelephony;
import com.l.mobliesafe.R;
import com.l.mobliesafe.db.dao.BlackNumberDao;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.telephony.gsm.SmsMessage;
import android.widget.Filter;

public class CallSafeService extends Service {

	
	
	private BlackNumberDao dao;
	private TelephonyManager tm;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	private MyContentObserver observer;
	private class MyPhoneStateListener extends PhoneStateListener {

	

		@Override
		public void onCallStateChanged(int state, String incomingNumber) {
			// TODO Auto-generated method stub
			super.onCallStateChanged(state, incomingNumber);

			switch (state) {

			case TelephonyManager.CALL_STATE_RINGING:
				String comingnum = dao.findByNum(incomingNumber);
				
				
				endCall();
				Uri uri=Uri.parse("content://call_log/calls");
				observer = new MyContentObserver(new Handler(),incomingNumber);
				getContentResolver().registerContentObserver(uri, true,observer);
				
				
				
				
				break;
			case TelephonyManager.CALL_STATE_IDLE:

				break;
			case TelephonyManager.CALL_STATE_OFFHOOK:
				System.out.println("正在打电话");
				break;

			default:
				break;
			}
		}
	}

	@Override
	public void onCreate() {
		super.onCreate();

		dao = new BlackNumberDao(this);

		tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		MyPhoneStateListener myPhoneStateListener = new MyPhoneStateListener();
		
		tm.listen(myPhoneStateListener,PhoneStateListener.LISTEN_CALL_STATE);

		InnerReceiver innerReceiver = new InnerReceiver();

		IntentFilter intentFilter = new IntentFilter(
				"android.provider.Telephony.SMS_RECEIVED");
		registerReceiver(innerReceiver, intentFilter);
	}

	public void endCall() {
		
		try {
			
			Class<?> clazz = getClassLoader().loadClass("android.os.ServiceManager");
			
			Method method = clazz.getDeclaredMethod("getService",String.class);	
			
			IBinder iBinder = (IBinder) method.invoke(null, TELEPHONY_SERVICE);
			
			ITelephony iTp = ITelephony.Stub.asInterface(iBinder);
			
			iTp.endCall();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	public class InnerReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {

			Object[] objects = (Object[]) intent.getExtras().get("pdus");

			for (Object obj : objects) {

				SmsMessage smsMessage = android.telephony.gsm.SmsMessage
						.createFromPdu((byte[]) obj);

				String smsAddress = smsMessage.getOriginatingAddress();
				String smsBody = smsMessage.getDisplayMessageBody();

				String mode = dao.findByNum(smsAddress);
				if (mode.equals("2") || mode.equals("3")) {

					abortBroadcast();
				}

			}

		}

	}
	
	public void deleteNum(String Num){
		Uri uri=Uri.parse("content://call_log/calls");
		
		getContentResolver().delete(uri, "number=?",new String[]{Num});
	}
	
	public class MyContentObserver extends ContentObserver{
		String mNumber;

		public MyContentObserver(Handler handler, String incomingNumber) {
			
			super(handler);
			this.mNumber=incomingNumber;
		
		}
		//当内容改变时调用的方法
		@Override
		public void onChange(boolean selfChange) {
			
			getContentResolver().unregisterContentObserver(this);
			deleteNum(mNumber);
			
			super.onChange(selfChange);
			
		}
	}


}
