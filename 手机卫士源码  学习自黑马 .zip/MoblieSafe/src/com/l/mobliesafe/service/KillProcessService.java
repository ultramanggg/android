package com.l.mobliesafe.service;

import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.IBinder;

public class KillProcessService extends Service {

	private SharedPreferences sp;
	private MyBroadcastReceiver receiver;


	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		sp = getSharedPreferences("config", Context.MODE_PRIVATE);
		sp.edit().putBoolean("killprocess",true);
		
		
		receiver = new MyBroadcastReceiver();
		
		IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		
		registerReceiver(receiver, filter);
		
	}
	
	public class MyBroadcastReceiver extends BroadcastReceiver{

		@Override
		public void onReceive(Context context, Intent intent) {
			
			ActivityManager am=(ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
			
			List<RunningAppProcessInfo> runningAppProcesses = am.getRunningAppProcesses();
			
			for (RunningAppProcessInfo rpi : runningAppProcesses) {
				
				String processName = rpi.processName;	
				//System.out.println(rpi.processName);
				am.killBackgroundProcesses(processName);
				
				
			}
			
		}
		
	}
	@Override
	public void onDestroy() {
		unregisterReceiver(receiver);
		receiver=null;
		//sp.edit().putBoolean("killprocess",false);
		super.onDestroy();
	}
	
}
