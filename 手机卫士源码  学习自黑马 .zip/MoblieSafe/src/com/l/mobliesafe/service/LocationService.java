package com.l.mobliesafe.service;



import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

public class LocationService extends Service {

	private SharedPreferences mPref;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate() {
		 LocationManager lm=(LocationManager) getSystemService(LOCATION_SERVICE);
	       mPref = getSharedPreferences("config", MODE_PRIVATE);
	        MyLocationListener mylocationlistener = new  MyLocationListener();
	        
			
			
			Criteria criteria = new Criteria();//位置提供方式最佳 选择的  标准累
			
			criteria.setCostAllowed(true);//是否付费
			
			criteria.setAccuracy(Criteria.ACCURACY_FINE);//设置精确度
			
			String bestProcvider=lm.getBestProvider(criteria , true);//根据标准获取最佳位置提供者。
			
			lm.requestLocationUpdates(bestProcvider, 60, 50, mylocationlistener);
			
			
		super.onCreate();
	}
	
	class MyLocationListener implements LocationListener{

		@Override
		public void onLocationChanged(Location location) {
			
			
			mPref.edit().putString("location", "j:"+location.getLongitude()+";w:"+location.getLatitude()).commit();
			stopSelf();
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

}
}