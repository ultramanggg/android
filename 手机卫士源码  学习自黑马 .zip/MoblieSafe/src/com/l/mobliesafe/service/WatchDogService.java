package com.l.mobliesafe.service;

import java.util.List;

import com.l.mobliesafe.activity.LockInputActivity;
import com.l.mobliesafe.db.dao.AppLockDao;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.os.SystemClock;

public class WatchDogService extends Service {

	private boolean wDogSwicth=false;
	private String packageName;
	private SharedPreferences sp; 
	@Override
	public IBinder onBind(Intent intent) {
		
		return null;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		sp = getSharedPreferences("config", MODE_PRIVATE);
		wDogSwicth=true;
		initWacthDog();
	}
	
	private void initWacthDog() {
		
			final ActivityManager am=(ActivityManager) getSystemService(ACTIVITY_SERVICE);
			final AppLockDao appLockDao = new AppLockDao(WatchDogService.this);
					
		new Thread(){
			public void run() {
				
				String b="";
			
				while (true) {
					
					List<RunningTaskInfo> runningTasks = am.getRunningTasks(1);
					RunningTaskInfo taskInfo = runningTasks.get(0);
					packageName = taskInfo.topActivity.getPackageName();
					
					
					if(b.equals("")&&appLockDao.find(packageName)){
						b=packageName;	
						appLockDao.setLockState(packageName, true);
					}
					
					if(!b.equals(packageName)&&!packageName.equals("com.l.mobliesafe")){
						if(b!=null){
							appLockDao.setLockState(b, true);
							
							b=packageName;
							
						}
						
						
						//System.out.println("包名变成了 "+packageName);
					}
					 
				
					if(appLockDao.find(packageName)&&appLockDao.islock(packageName)){
						
													
							
						appLockDao.setLockState(packageName, false);
						//System.out.println(appLockDao.islock(packageName)+"当前的值");
						startActivity(new Intent(WatchDogService.this,LockInputActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
						
							
							
							
					
					}
					//SystemClock.sleep(500);
					//System.out.println(packageName);
					
					
					if(!wDogSwicth){
						//System.out.println("循环  停止了  运行");
						break;
					}
					
				}
				
			};
		}.start();
	}

	@Override
	public void onDestroy() {
		wDogSwicth=false;
		super.onDestroy();
		
	}
	

}
