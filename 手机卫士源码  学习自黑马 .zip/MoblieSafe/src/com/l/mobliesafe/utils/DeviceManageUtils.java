package com.l.mobliesafe.utils;

import com.l.mobliesafe.activity.SetUp4Activity;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class DeviceManageUtils {

	
	private static DevicePolicyManager mdPM;

	/**
	 * 开启设备管理器的方法
	 * @param 将使用该方法的activity自己
	 */
	
	 
	 public static  DevicePolicyManager getDevicePolicyManager(Activity context){
		 
		return (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
	 }
	
	public static void activeDeviceManage(Activity context){
		Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
		intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,new ComponentName(context, com.l.mobliesafe.admin.AdnimReceiver.class));
		intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"开启了设备管理功能");
		context.startActivity(intent);
	}
	
	public  static void cancelDeviceManage(Activity context){
		DevicePolicyManager mdPM =(DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
		mdPM.removeActiveAdmin(new ComponentName(context, com.l.mobliesafe.admin.AdnimReceiver.class));
	}
}
