package com.l.mobliesafe.utils;

import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;

/**
 * 
 * 服务状态检测工具
 * 
 * @author huawe p7
 * 
 */
public class ServiceStatusUtils {

	/**
	 * @param context
	 *            判断服务是否开启的 context对象
	 * @param serviceNmae
	 *            服务的全路径名
	 * @return 服务是否开启
	 */
	public static boolean isServiceRunning(Context context, String serviceName) {
		ActivityManager am = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningServiceInfo> runningServices = am.getRunningServices(100);
		for (RunningServiceInfo runningServiceInfo : runningServices) {

			String runningServiceName = runningServiceInfo.service
					.getClassName();

			if (runningServiceName.equals(serviceName)) {

				
				return true;
			} 
		}
		return false;
	}

}
