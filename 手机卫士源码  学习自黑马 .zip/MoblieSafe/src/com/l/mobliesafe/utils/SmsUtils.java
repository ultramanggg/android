package com.l.mobliesafe.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.xmlpull.v1.XmlSerializer;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Message;
import android.os.SystemClock;
import android.util.Xml;

public class SmsUtils {

	/**
	 * 
	 * 备份短信的方法
	 * 
	 * @param context
	 *            调用该方法的context
	 * @param pd
	 * @return 备份是否成功
	 */

	public interface GetBackupData {

		public void getSmsCount(int Count);

		public void getBackupCount(int progress);
	}

	public static boolean backUp(Context context, GetBackupData callback) {

		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {

			ContentResolver resolver = context.getContentResolver();
			Uri uri = Uri.parse("content://sms/");
			Cursor cursor = resolver.query(uri, new String[] { "address",
					"date", "type", "body" }, null, null, null);
			if(callback!=null){
				callback.getSmsCount(cursor.getCount());
			}
			

			try {

				File file = new File(Environment.getExternalStorageDirectory(),
						"sms.xml");

				FileOutputStream out = new FileOutputStream(file);

				// 序列化机器
				XmlSerializer serializer = Xml.newSerializer();
				serializer.setOutput(out, "utf-8");
				// 设置文件的开始
				serializer.startDocument("utf-8", true);
				// 设置开始标签
				serializer.startTag(null, "smss");
				serializer.attribute(null, "size", cursor.getCount() + "");
				int i = 0;

				int progress = 0;
				while (cursor.moveToNext()) {

					String address = cursor.getString(0);
					String date = cursor.getString(1);
					String type = cursor.getString(2);
					String body = Crypto.encrypt("123", cursor.getString(3));

					serializer.startTag(null, "sms");
					serializer.startTag(null, "address");
					serializer.text(address);
					serializer.endTag(null, "address");
					serializer.startTag(null, "date");
					serializer.text(date);
					serializer.endTag(null, "date");
					serializer.startTag(null, "type");
					serializer.text(type);
					serializer.endTag(null, "type");
					serializer.startTag(null, "body");
					serializer.text(body);
					serializer.endTag(null, "body");
					serializer.endTag(null, "sms");

					SystemClock.sleep(500);
					progress++;
					if (callback != null) {
						callback.getBackupCount(progress);
					}
				}
				// 设置结束的标签
				serializer.endTag(null, "smss");
				// 设置文件的结束
				serializer.endDocument();
				cursor.close();
				out.flush();
				out.close();

			} catch (Exception e) {
				e.printStackTrace();

				return false;
			}

		}

		return true;

	}

	public static String MD5Encode(String text) {
		try {
			MessageDigest digest = MessageDigest.getInstance("MD5");

			byte[] result = digest.digest(text.getBytes());
			StringBuffer buffer = new StringBuffer();
			for (byte b : result) {
				int num = b & 0xff;
				String hexString = Integer.toHexString(num);

				if (hexString.length() == 1) {
					buffer.append("0" + hexString);
				} else {
					buffer.append(hexString);
				}

			}

			return buffer.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return "";
		}
	}
}
