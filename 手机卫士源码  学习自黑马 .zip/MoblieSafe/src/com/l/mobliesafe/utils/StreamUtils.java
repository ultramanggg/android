package com.l.mobliesafe.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class StreamUtils {

	public static String readFormStream(InputStream in) throws IOException{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		
		int length=0;
		
		byte[] buffer =new byte[1024];
		
		while((length=in.read(buffer))>0){
			
			out.write(buffer,0,length);
		}
		
		String  resualt = out.toString();
		
		in.close();
		out.close();
		
		return resualt;
		
	}
}