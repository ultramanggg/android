package com.l.mobliesafe.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 
 * 获取焦点的textView
 * @author huawe p7
 *
 */
public class FocusedTextView extends TextView {
	
	//生成方法
	public FocusedTextView(Context context) {
		super(context);
		
	}
	
	//带有样式的方法
	public FocusedTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		
	}
	//有属性时的方法
	public FocusedTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
	}
	
	/* 
	 * 只有这个方法  返回 ture时  跑马灯才有效果；
	 * 修改此方法返回值为   真   使得系统默认可以使用跑马灯
	 */
	@Override
	public boolean isFocused() {
		
		return true;
	}
	
}
