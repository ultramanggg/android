package com.l.mobliesafe.view;

import com.l.mobliesafe.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SettingClickView extends RelativeLayout {

	private TextView tvtitle;
	private TextView tvDesc;
	private ImageView ivStatus;
	private	static final String NAMESPACE="http://schemas.android.com/apk/res/com.l.mobliesafe";
	
	private String mThemeName;
	private String mDesc;

	public SettingClickView(Context context) {

		super(context);
		initView();
	}

	public SettingClickView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public SettingClickView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		
		mThemeName = attrs.getAttributeValue(NAMESPACE, "theme");
		mDesc = attrs.getAttributeValue(NAMESPACE, "desc");
		
		
		
		initView();
		setTitle(mThemeName);
		setDesc(mDesc);
	}

	private void initView() {
		// 将布局给我们创建的这个类
		View view = View.inflate(getContext(), R.layout.view_setting_click, this);

		tvtitle = (TextView) findViewById(R.id.tv_title);
		tvDesc = (TextView) findViewById(R.id.tv_desc);
		ivStatus = (ImageView) findViewById(R.id.iv_status);
		
		tvtitle.setText("sdasd");
		
	
	}

	public void setTitle(String theme){
		tvtitle.setText(theme);
		
	}
	
	public void setDesc(String desc){
		tvDesc.setText(desc);
	}
	

}
