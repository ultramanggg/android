package com.l.mobliesafe.view;

import com.l.mobliesafe.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SettingItemView extends RelativeLayout {

	private TextView tvtitle;
	private TextView tvDesc;
	private CheckBox cbStatus;
	private	static final String NAMESPACE="http://schemas.android.com/apk/res/com.l.mobliesafe";
	private String mTitle;
	private String mDesc_on;
	private String mDesc_off;

	public SettingItemView(Context context) {

		super(context);
		initView();
	}

	public SettingItemView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initView();
	}

	public SettingItemView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		
		mTitle = attrs.getAttributeValue(NAMESPACE, "title");
		mDesc_on = attrs.getAttributeValue(NAMESPACE, "desc_on");
		mDesc_off = attrs.getAttributeValue(NAMESPACE, "desc_off");
		
		
		initView();
		
	}

	private void initView() {
		// 将布局给我们创建的这个类
		View view = View
				.inflate(getContext(), R.layout.view_setting_item, this);

		tvtitle = (TextView) findViewById(R.id.tv_title);
		tvDesc = (TextView) findViewById(R.id.tv_desc);
		cbStatus = (CheckBox) findViewById(R.id.cb_status);
		
		setTitle(mTitle);
		
		setCheckBoxStatus(false);
	}

	public void setTitle(String title) {
		tvtitle.setText(title);
	}

	public void setDesc(String desc) {
		tvDesc.setText(desc);
	}

	public boolean isChecked() {
		return cbStatus.isChecked();
	}

	public void setCheckBoxStatus(boolean status) {

		cbStatus.setChecked(status);
		
		if(status){
			setDesc(mDesc_on);
		}else{
			setDesc(mDesc_off);
		}
	}

}
