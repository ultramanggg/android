package com.zsl.neonlight.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.zsl.neonlight.R;

public class ShowActivity extends Activity {

	private static final int LIU_OPEN = 0;
	protected static final int HUAN_YING_OPEN = 1;
	private static final int UPDATE_DIANQI = 2;
	protected static final int HUAN_YING_CLOSE = 3;
	private TextView tl;
	float x0 = 0;
	float x1 = 0;
	boolean jStopIng = false;// 是否处在急停的状态
	private TranslateAnimation traslatRight;
	private TranslateAnimation traslatLeft;
	private LinearLayout cebian;
	int liuCi = 0;
	private ImageView liu;
	private Message msgliuUpdate;// 开启流的消息
	boolean t = true;// 闪烁的状态变量
	int[] liuId = new int[] { R.drawable.liu1, R.drawable.liu2,
			R.drawable.liu3, R.drawable.liu4 };

	Handler mhander = new Handler() {

		public void handleMessage(android.os.Message msg) {

			switch (msg.what) {

			case HUAN_YING_OPEN:// 开启欢迎光临
				if(jStopIng){
					break;
				}
				// -------------
				// System.out.println(openBS+"ooo");
				if (openBS == 0) {
					huan.setTextColor(Color.YELLOW);
				}
				if (openBS == 1) {
					ying.setTextColor(Color.YELLOW);
				}

				if (openBS == 2) {
					guang.setTextColor(Color.YELLOW);
				}

				if (openBS == 3) {
					lin.setTextColor(Color.YELLOW);
				}
				// -------------------开启欢迎光临

				break;
				
			case HUAN_YING_CLOSE:// 关欢迎光临
				// -------------
				if(jStopIng){
					break;
				}
				// System.out.println(openBS+"ooo");
				if (closeBS == 0) {
					lin.setTextColor(Color.BLACK);
					
				}
				if (closeBS == 1) {
					
					
					guang.setTextColor(Color.BLACK);
				}

				if (closeBS == 2) {
					ying.setTextColor(Color.BLACK);
				}

				if (closeBS == 3) {
					huan.setTextColor(Color.BLACK);
				}
				// -------------------开启欢迎光临

				break;

			case LIU_OPEN:
				if(jStopIng){
					break;
				}

				msgliuUpdate = Message.obtain();
				msgliuUpdate.what = LIU_OPEN;

				if (LiuRuning) {
					liu.setImageResource(liuId[liuCi]);
					liuCi++;
					if (liuCi == 4) {
						liuCi = 0;
					}

					mhander.sendMessageDelayed(msgliuUpdate, 1000);
				} else {

					liu.setImageResource(R.drawable.liu_close);
				}

				break;

			case UPDATE_DIANQI:
				if(jStopIng){
					break;
				}

				updateDianQiMsg = Message.obtain();
				updateDianQiMsg.what = UPDATE_DIANQI;

				if (DianQiRuning) {
					if (t) {
						dainqi.setTextColor(Color.RED);
					} else {
						dainqi.setTextColor(Color.BLACK);
					}

					t = !t;
					mhander.sendMessageDelayed(updateDianQiMsg, 500);

				} else {

					dainqi.setTextColor(Color.BLACK);
				}

				break;

			default:
				break;
			}

		};
	};
	private ImageView ring;
	private ImageView jian;
	private ImageView shen;
	private ImageView lian;
	private ImageView mao;
	private TextView huan;
	private TextView ying;
	private TextView guang;
	private TextView lin;
	private TextView dainqi;
	private ImageView zhishi;
	private TextView jiting;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_show);
		initView();
		initAnimation();
	}

	private void initAnimation() {

		traslatRight = new TranslateAnimation(-360, 0, 0, 0);
		traslatRight.setDuration(500);
		traslatRight.setFillAfter(true);

		// ----------------
		traslatLeft = new TranslateAnimation(0, -360, 0, 0);
		traslatLeft.setDuration(500);
		traslatLeft.setFillAfter(true);

	}

	public void initView() {
		
		
		sb = (SeekBar) findViewById(R.id.guang_seekbar);
		sb.setMax(400);
		sb.setEnabled(false);
		sb.setProgress(0);
		tl = (TextView) findViewById(R.id.tl);
		cebian = (LinearLayout) findViewById(R.id.cebian);
		liu = (ImageView) findViewById(R.id.liu);
		ring = (ImageView) findViewById(R.id.ring);
		jian = (ImageView) findViewById(R.id.jian);
		shen = (ImageView) findViewById(R.id.shen);
		lian = (ImageView) findViewById(R.id.lian);
		mao = (ImageView) findViewById(R.id.mao);
		huan = (TextView) findViewById(R.id.huan);
		ying = (TextView) findViewById(R.id.ying);
		guang = (TextView) findViewById(R.id.guang);
		lin = (TextView) findViewById(R.id.lin);
		dainqi = (TextView) findViewById(R.id.dianqi);
		zhishi = (ImageView) findViewById(R.id.zhishi);
		jiting = (TextView) findViewById(R.id.jiting);
	}

	boolean isok =true;
	@Override
	public boolean onTouchEvent(MotionEvent event) {

		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:

			x0 = event.getX();

			break;
		case MotionEvent.ACTION_MOVE:
			x1 = event.getX();

			break;

		case MotionEvent.ACTION_UP:

			if (x1 - x0 > 20&&isok) {
				cebian.startAnimation(traslatRight);
				for (int i = 0; i < cebian.getChildCount(); i++) {

					cebian.getChildAt(i).setEnabled(true);
				}
				isok=false;
			}
			if (x1 - x0 < -20&&!isok) {
				cebian.startAnimation(traslatLeft);
				for (int i = 0; i < cebian.getChildCount(); i++) {

					cebian.getChildAt(i).setEnabled(false);
				}
				isok=true;
			}
			break;

		default:
			break;
		}

		return super.onTouchEvent(event);
	}

	// 白天启动
	public void qStart(View v) {
		//Toast.makeText(this, "白天模式", 0).show();
		if(jStopIng){
			
			Toast.makeText(this,"当前处于急停状态 请关闭急停后尝试", 0).show();
		}else{
			// 关闭夜景指示灯---------
			zhishi.setImageResource(R.drawable.zhishi_colse);
			stopGseekBar();
			// -------------------------------------
			neonStart();
		}
		
	}

	// 晚上启动
	int Guang_qiang=0;//光线的强度。
	public void yStart(View v) {

		//判断是不是急停的状态
		if(jStopIng){
			
			Toast.makeText(this,"当前处于急停状态 请关闭急停后尝试", 0).show();
		}else{
			// 开启夜景指示灯---------
			zhishi.setImageResource(R.drawable.zhishi);
			// -------------------------------------
			startGseekBar();
			
			if(Guang_qiang<200){
				
				if(!neonOpen){
					neonStart();
					
				}
			}else{
				
				
				if(neonOpen){
					noenStop();
					
				}
				
			}
			
		}
		
	}

	// 停止
	public void stop(View v) {
		
		
		
		//判断是不是急停的状态
		if(jStopIng){
			
			Toast.makeText(this,"当前处于急停状态 请关闭急停后尝试", 0).show();
		}else{
			// 关闭夜景指示灯---------
			zhishi.setImageResource(R.drawable.zhishi_colse);
			stopGseekBar();
			// -------------------------------------
			
			noenStop();
		}
		
	}

	// 紧急停止
	public void jStop(View v) {

		
		// 判断是否处于急停状态
		if (jStopIng) {
			jiting.setVisibility(jiting.INVISIBLE);
			jStopIng = false;
		} else {
			// 关闭夜景指示灯*************************************
			zhishi.setImageResource(R.drawable.zhishi_colse);
			stopGseekBar();
			// **************************************************
			jiting.setVisibility(jiting.VISIBLE);
			jStopIng = true;
			openBS=0;
			closeBS=0;
			neonOpen=false;
			LiuRuning=false;
			DianQiRuning=false;
			//设置颜色为关闭；
			huan.setTextColor(Color.BLACK);
			ying.setTextColor(Color.BLACK);
			guang.setTextColor(Color.BLACK);
			lin.setTextColor(Color.BLACK);
			
			liu.setImageResource(R.drawable.liu_close);
			ring.setImageResource(R.drawable.huan_close);
			
			jian.setImageResource(R.drawable.jian_close);
			shen.setImageResource(R.drawable.shen_close);
			lian.setImageResource(R.drawable.lian_close);
			mao.setImageResource(R.drawable.mao_close);
			
			dainqi.setTextColor(Color.BLACK);
		}
		// ****************************************************
		//置0记录变量
	
		
	}

	// 展示流程图
	public void showTU(View v) {
		//Toast.makeText(this, "还没有加入流程图", 0).show();
		startActivity(new Intent(this, TuActivity.class));
	}

	// 展示流程图
	public void showTiShi(View v) {
		//Toast.makeText(this, "还没有加入接线图", 0).show();
		Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("系统帮助");
		builder.setMessage("本系统用于展示霓虹灯广告屏幕的效果  作者：zsl \n不使用系统权限\n不妨问任何数据\n软件素材和代码由zsl独自完成\n如有需要请联系qq：524160945");
		builder.create().show();
	}

	// ----------------
	int openBS = 0;// 开始到了第几步
	boolean neonOpen = false;// 霓虹灯是打开的吗？

	// 开启霓虹灯
	public void neonStart() {
		isopen=true;
		if (!neonOpen) {

			

			new Thread() {
				public void run() {
					openBS = 0;
					
					while (!neonOpen) {
						
						if(jStopIng){
							break;
						}
						if (openBS == 0) {
							Message message = Message.obtain();
							message.what = HUAN_YING_OPEN;
							mhander.sendMessage(message);
						}
						if (openBS == 1) {
							Message message = Message.obtain();
							message.what = HUAN_YING_OPEN;
							mhander.sendMessage(message);
						}
						if (openBS == 2) {
							Message message = Message.obtain();
							message.what = HUAN_YING_OPEN;
							mhander.sendMessage(message);
						}

						if (openBS == 3) {
							Message message = Message.obtain();
							message.what = HUAN_YING_OPEN;
							mhander.sendMessage(message);
						}
						// 开启循环灯
						if (openBS == 4) {

							updateLiuState();

						}
						// 开启紫色圆环
						if (openBS == 5) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									ring.setImageResource(R.drawable.huan_open);
								}
							});
							// **********
						}
						// 开启箭头
						if (openBS == 6) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									jian.setImageResource(R.drawable.jian_open);
								}
							});
							// **********
						}
						// 开启身体
						if (openBS == 7) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									shen.setImageResource(R.drawable.shen_open);
								}
							});
							// **********
						}
						// 开启脸部
						if (openBS == 8) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									lian.setImageResource(R.drawable.lian_open1);
								}
							});
							// **********
						}
						if (openBS == 9) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									lian.setImageResource(R.drawable.lian_open2);
								}
							});
							// **********
						}

						// 开启帽子
						if (openBS == 10) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									mao.setImageResource(R.drawable.mao_open);
								}
							});
							// **********
						}
						// 开启建筑电气
						if (openBS == 11) {
							updateDianQiState();

							// openBS = 0;

						}

						SystemClock.sleep(1000);
						if (openBS < 12) {
							openBS++;

						} else {
							openBS=0;
							neonOpen = true;
							break;
						}
					}

				}

			}.start();
		}
	}

	/**
	 * 更新流动灯的状态；
	 * 
	 */
	boolean LiuRuning = false;

	private void updateLiuState() {

		if (LiuRuning) {
			// 发送关闭流动灯的消息；

			msgliuUpdate = Message.obtain();
			msgliuUpdate.what = LIU_OPEN;

			mhander.sendMessageDelayed(msgliuUpdate, 0);

			LiuRuning = false;
		} else {

			// 开启流动灯；

			msgliuUpdate = Message.obtain();
			msgliuUpdate.what = LIU_OPEN;

			mhander.sendMessageDelayed(msgliuUpdate, 0);
			LiuRuning = true;
		}

	};

	/**
	 * 更新 建筑电气 灯的状态；
	 * 
	 */
	boolean DianQiRuning = false;// 电气是否开启
	private Message updateDianQiMsg;

	private void updateDianQiState() {

		DianQiRuning = !DianQiRuning;

		updateDianQiMsg = Message.obtain();
		updateDianQiMsg.what = UPDATE_DIANQI;

		mhander.sendMessage(updateDianQiMsg);

	}

	int closeBS = 0;// 开始到了第几步
	private SeekBar sb;

	public void noenStop() {
		isopen=false;
		// 霓虹灯是开的状态才能使用；
		if (neonOpen) {

			closeBS = 0;

			new Thread() {
				public void run() {

					while (neonOpen) {

						// --------不同的步数处理的事件
						if(jStopIng){
							break;
						}

						if (closeBS == 0) {
							
							Message obtain = Message.obtain();
							obtain.what=HUAN_YING_CLOSE;
							mhander.sendMessage(obtain);

						}
						if (closeBS == 1) {
							
							Message obtain = Message.obtain();
							obtain.what=HUAN_YING_CLOSE;
							mhander.sendMessage(obtain);

						}
						if (closeBS == 2) {
							
							Message obtain = Message.obtain();
							obtain.what=HUAN_YING_CLOSE;
							mhander.sendMessage(obtain);

						}
						if (closeBS == 3) {
							
							Message obtain = Message.obtain();
							obtain.what=HUAN_YING_CLOSE;
							mhander.sendMessage(obtain);

						}
						//关闭流动
						if (closeBS == 4) {
							updateLiuState();
						}
						//关闭紫环
						if (closeBS == 5) {
							// ****
							runOnUiThread(new Runnable() {
								public void run() {
									ring.setImageResource(R.drawable.huan_close);
								}
							});
							// **********
						}
						//关闭箭头
						if (closeBS == 6) {
							runOnUiThread(new Runnable() {
								public void run() {
									jian.setImageResource(R.drawable.jian_close);
								}
							});
						}
						//关闭身子
						if (closeBS == 7) {
							runOnUiThread(new Runnable() {
								public void run() {
									shen.setImageResource(R.drawable.shen_close);
								}
							});
						}
						//关闭脸
						if (closeBS == 8) {
							runOnUiThread(new Runnable() {
								public void run() {
									lian.setImageResource(R.drawable.lian_close);
								}
							});
						}
						//关闭帽子
						if (closeBS == 9) {
							runOnUiThread(new Runnable() {
								public void run() {
									mao.setImageResource(R.drawable.mao_close);
								}
							});
						}
						//关闭建筑电气
						if (closeBS == 10) {
							updateDianQiState();
						}
						

						// ---------------
						SystemClock.sleep(1000);

						if (closeBS < 11) {
							closeBS++;

						} else {
							neonOpen = false;
							closeBS = 0;
							break;
						}

					}

				};

			}.start();

		}
	}
	
	boolean Gce=false;
	boolean isopen=true;
	public void startGseekBar(){
		
		sb.setVisibility(sb.VISIBLE);
		sb.setEnabled(true);
		Gce=true;
		new Thread(){
			
			public void run() {
				while(Gce){
					
					Guang_qiang=sb.getProgress();
					//System.out.println(Guang_qiang+"光线强度");
					
						if(Guang_qiang<200){
							if(!isopen){
								neonStart();
							}
							
								
							
						}else{
							
							if(isopen){
								noenStop();
							}
							
						}
						
					
					
					SystemClock.sleep(500);
				}
				
			};
			
		}.start();
		
	}
	
	public void stopGseekBar(){
		
		sb.setVisibility(sb.INVISIBLE);
		sb.setEnabled(false);
		Gce=false;
	}
}
