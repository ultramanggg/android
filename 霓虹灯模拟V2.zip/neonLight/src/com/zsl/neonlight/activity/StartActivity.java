package com.zsl.neonlight.activity;

import com.zsl.neonlight.R;
import com.zsl.neonlight.R.layout;
import com.zsl.neonlight.R.menu;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class StartActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void ComeIn(View v){
		
		startActivity(new Intent(StartActivity.this,ShowActivity.class));
		
	}
}
