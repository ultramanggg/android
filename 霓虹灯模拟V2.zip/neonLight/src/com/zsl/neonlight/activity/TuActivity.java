package com.zsl.neonlight.activity;


import com.zsl.neonlight.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class TuActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tu);
	}

	public void close(View v){
		finish();
	}
}
